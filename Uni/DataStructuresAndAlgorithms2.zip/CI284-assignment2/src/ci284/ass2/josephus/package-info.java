/**
 * This package contains the class which will form the basis of your solution to the Josephus problem.
 */
/**
 * @author jb259
 *
 */
package ci284.ass2.josephus;