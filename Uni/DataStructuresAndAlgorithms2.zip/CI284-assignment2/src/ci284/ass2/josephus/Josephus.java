/*
 * Author: Emmanouil Lainas
 * Reg.Num: 12847191
 * Data Structures & Algorithms Assignment 2
 */
package ci284.ass2.josephus;

import ci284.ass2.cl.CListMoreEfficient;

/*
 * This implementation of the Josephus algorithm covers the cases
 * where the list is empty, checks if the list has
 * only 1 element stored in it, otherwise it performs the algorithm.
 * In order to reach the starting point we call the next() method
 * start times. The equation start=start%list.length() does the
 * trick to avoid unnecessary loops if start is larger than the length.
 * After that there are 2 nested loops. While the length of the
 * list is not 1, call the next() method interval-1 times(we call the
 * method, interval-1 times because interval it is not 0-index-based)
 * and then remove the element from position 0. Using the nested loops
 * means that in the worst case the algorithm will run in O(N^2).
 * This is NOT the most efficient way to perform the algorithm. This is
 * because of the remove(int) method from the CListMoreEfficient. Because in
 * the implementation of the remove method, when we want to
 * remove from anywhere in the middle of the list the current does not change.
 * Which means that for current to change, remove() must occur at position 0.
 * If when removing from the list, current was changing to the element after
 * the one removed,
 * 	 
 			while(list.length()!=1){
				for(int j=0;j<interval-1;j++){
					list.next();
				}
				list.remove(0);
			}
 * 
 * this block would have been replaced with
 * 
 			while(list.length()!=1){
				list.remove(interval-1);
			}
 *Thus in the worst case the algorithm would run in O(n). As interval increases
 *the algorithm becomes more complex.
 */

public class Josephus {
	
	/**
	 * findSurvivor returns the surviving element from the input list by solving the Josephus problem.
	 * @param list
	 * @param start
	 * @param interval
	 * @return
	 */
	public static <T> T findSurvivor(CListMoreEfficient<T> list, int start, int interval) {
		//if list is empty return null
		if(list.length()==0){
			return null;
		}
		//else if the list has only one element return it
		else if(list.length()==1){
				return list.getCurrent();
		}
		//in every other case update start to avoid unnecessary loops
		else{
			start=start%list.length();
			//find start element
			for(int i=0;i<start;i++){
				list.next();
			}
			//call next interval-1 times and remove
			//this element while the length of the list
			//is not equal with 1
			while(list.length()!=1){
				for(int j=0;j<interval-1;j++){
					list.next();
				}
				list.remove(0);
			}
			return list.getCurrent();
		}
	}
}
