package ci284.ass2.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import ci284.ass2.cl.CListMoreEfficient;
import ci284.ass2.josephus.Josephus;

public class TestJosephus {

	@Before
	public void setUp() throws Exception {
	}
	
	@Test
	public void testClassicScenario() {
		CListMoreEfficient<Integer> l1 = new CListMoreEfficient<Integer>();
		for(int i=41;i>0;i--) l1.insert(i);
		assertEquals(31, Josephus.findSurvivor(l1, 0, 3).intValue());
	}
	
	@Test
	public void testNull() {
		CListMoreEfficient<Integer> l1 = new CListMoreEfficient<Integer>();
		assertNull(Josephus.findSurvivor(l1, 0, 3));
	}
	
	@Test
	public void testWrapAround() {
		CListMoreEfficient<Integer> l1 = new CListMoreEfficient<Integer>();
		for(int i=7;i>0;i--) l1.insert(i);
		assertEquals(7, Josephus.findSurvivor(l1, 0, 9).intValue());
	}
	
	@Test
	public void testNonZeroStart() {
		CListMoreEfficient<Integer> l1 = new CListMoreEfficient<Integer>();
		for(int i=7;i>0;i--) l1.insert(i);
		assertEquals(6, Josephus.findSurvivor(l1, 2, 3).intValue());
	}

	@Test
	public void testStrings() {
		CListMoreEfficient<String> l1 = new CListMoreEfficient<String>();
		l1.insert("Carol");
		l1.insert("Bob");
		l1.insert("Alice");
		l1.insert("Josephus");
		assertEquals("Josephus", Josephus.findSurvivor(l1, 0, 2));
	}

}
