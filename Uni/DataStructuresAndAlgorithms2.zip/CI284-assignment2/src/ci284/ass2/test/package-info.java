/**
 * This package contains unit tests which you can use to check your progress on assignment 2.
 */
/**
 * @author jb259
 *
 */
package ci284.ass2.test;