/**
 * This package contains the classes which should form the basis of your circular lists.
 */
/**
 * @author jb259
 *
 */
package ci284.ass2.cl;