/*
 * Author: Emmanouil Lainas
 * Reg.Num: 12847191
 * Data Structures & Algorithms Assignment 2
 */
package ci284.ass2.cl;

/*
 * This is a more efficient approach, as the name suggests
 * where we keep reference to the element that was firstly added
 * this way our inserting operations are less costly as well as removing
 */
public class CListMoreEfficient<T> {
	//extra variable to keep reference of the firstly added element
	private ListItem<T> current,temp1,temp2,firstadded;
	//initialisation of length
	public int length = 0;

	//get length of list
	public int length() {
		return length;
	}
	
	//get the value of current
	public T getCurrent() {		
		return current.data;
	}

	//get the next element in the list
	//it is important to note that whenever next is called
	//the fisrt added moves as well.
	public T next() {		
		current=current.getNext();
		firstadded=firstadded.getNext();
		return current.data;
	}

	//if list is empty create the first element in current
	//and keep a reference of it as first added
	public void insert(T e){
		if(current==null){
			current = new ListItem<T>(e);
			current.setNext(current);
			firstadded=current;
			length++;
		}
		//now that the list is not empty, but we have e reference of
		//the element added at the beginning, insertion becomes very simple
		else{
			//store current in variable
			temp1 = current;
			//create the new current, most recently added element
			current = new ListItem<T>(e);
			//set the next of current and the next of the firstadded
			current.setNext(temp1);
			firstadded.setNext(current);
			length++;
		}
	}
	//for removal the same cases as in the other example are covered
	//but again in this implementation loops are being used only when 
	//needed.
	public T remove(int index) {
		if(length==0)
			return null;
		else if(length==1){
			current = null;
			firstadded=null;
			length--;
			return current.data;
		}
		else{
			//if index 0 needs to be removed ore o multiple of it
			//we simply rearrange the pointers
			if((index%length)==0){
				current=current.getNext();
				firstadded.setNext(current);
				length--;
				return current.data;
			}
			//else in worst case loop to index position and remove
			else{
				temp1=current;
				for(int i=0;i<index-1;i++){
					temp1=temp1.getNext();
				}
				temp2=temp1;
				temp2=temp2.getNext();
				temp2=temp2.getNext();
				temp1.setNext(temp2);
				length--;
				return current.data;
			}
		}	
	}	

	
	public String toString() {
		StringBuffer res = new StringBuffer();
		if (current != null) {
			ListItem<T> li = current;
			boolean beenRound = false;
			while (true) {
				if (li.equals(current)) {
					if (beenRound) {
						res.append("↩");
						break;
					} else {
						beenRound = true;
					}
				} 
				res.append(li.toString());
				li = li.getNext();
			}
		}
		return res.toString();
	}
}
