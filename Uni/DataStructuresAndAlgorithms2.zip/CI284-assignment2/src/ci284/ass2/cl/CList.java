/*
 * Author: Emmanouil Lainas
 * Reg.Num: 12847191
 * Data Structures & Algorithms Assignment 2
 */
package ci284.ass2.cl;

/*
 * Two implementations are provided for question one. In this approach
 * only the pointer "current" is used and the list always uses loops
 * when inserting or removing an element which is less efficient.
 */

public class CList<T> {
	
	//declaration of current pointer and temporary's
	private ListItem<T> current,temp1,temp2;
	//initialisation of the list length
	public int length = 0;

	//get the length of a list
	public int length() {
		return length;
	}
	
	//get the value of current
	public T getCurrent() {		
		return current.data;
	}
	
	//get the next element in the list
	public T next() {		
		current=current.getNext();
		return current.data;
	}
	
	//insert element in the list
	public void insert(T e){
		//if the list is empty create the first element
		if(current==null){
			current = new ListItem<T>(e);
			current.setNext(current);			
			length++;
		}
		//otherwise loop to the end and add the new element
		else{
			temp1 = new ListItem<T>(e);
			temp1.setNext(current);
			
			for(int i=0;i<length-1;i++){
				current=current.getNext();
			}
			current.setNext(temp1);
			length++;
			current=current.getNext();
		}
	}
	
	//remove element from list
	//removal is basicaly done by tracking the element before
	//the one to be removed and connection it with the one after
	//the element we want to remove
	public T remove(int index) {
		//first case is if its empty, then return null
		if(length==0)
			return null;
		//else if there is only one element in the list delete it
		else if(length==1){
			current = null;
			length--;
			return current.data;
		}
		//if neither of the above, check if "index%length)==0"
		//this formula is to cover the case for any removing where
		//the index points again to position 0
		else{
			if((index%length)==0){
				for(int i=0;i<length-1;i++){
					current=current.getNext();
				}
				temp1=current;
				current=current.getNext();
				current=current.getNext();
				temp1.setNext(current);
				length--;
				return current.data;
			}
			//otherwise just loop depending on index and
			//remove the element
			else{
				temp1=current;
				for(int i=0;i<index-1;i++){
					temp1=temp1.getNext();
				}
				temp2=temp1;
				temp2=temp2.getNext();
				temp2=temp2.getNext();
				temp1.setNext(temp2);
				length--;
				return current.data;
			}
		}	
	}	

	
	public String toString() {
		StringBuffer res = new StringBuffer();
		if (current != null) {
			ListItem<T> li = current;
			boolean beenRound = false;
			while (true) {
				if (li.equals(current)) {
					if (beenRound) {
						res.append("↩");
						break;
					} else {
						beenRound = true;
					}
				} 
				res.append(li.toString());
				li = li.getNext();
			}
		}
		return res.toString();
	}     

	/*
	private ListItem<T> current,temp1,temp2,firstadded;
	public int length = 0;

	public int length() {
		return length;
	}
	
	public T getCurrent() {		
		return current.data;
	}

	public T next() {		
		current=current.getNext();
		firstadded=firstadded.getNext();
		return current.data;
	}

	public void insert(T e){
		if(current==null){
			current = new ListItem<T>(e);
			current.setNext(current);
			firstadded=current;
			length++;
		}
		else{
			temp1 = current;
			current = new ListItem<T>(e);
			current.setNext(temp1);
			firstadded.setNext(current);
			length++;
		}
	}

	public T remove(int index) {
		if(length==0)
			return null;
		else if(length==1){
			current = null;
			firstadded=null;
			length--;
			return current.data;
		}
		else{
			if((index%length)==0){
				current=current.getNext();
				firstadded.setNext(current);
				length--;
				return current.data;
			}
			else{
				temp1=current;
				for(int i=0;i<index-1;i++){
					temp1=temp1.getNext();
				}
				temp2=temp1;
				temp2=temp2.getNext();
				temp2=temp2.getNext();
				temp1.setNext(temp2);
				length--;
				return current.data;
			}
		}	
	}	

	
	public String toString() {
		StringBuffer res = new StringBuffer();
		if (current != null) {
			ListItem<T> li = current;
			boolean beenRound = false;
			while (true) {
				if (li.equals(current)) {
					if (beenRound) {
						res.append("↩");
						break;
					} else {
						beenRound = true;
					}
				} 
				res.append(li.toString());
				li = li.getNext();
			}
		}
		return res.toString();
	}
	*/
	
}
