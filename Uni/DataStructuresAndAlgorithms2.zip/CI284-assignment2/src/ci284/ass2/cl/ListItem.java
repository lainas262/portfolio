package ci284.ass2.cl;

public class ListItem<T> {
	T data;
	ListItem<T> next;
	
	public ListItem(T data) {
		this.data = data;
	}
	
	public ListItem<T> getNext() {
		return next;
	}
	
	public void setNext(ListItem<T> next) {
		this.next = next;
	}
	
	public String toString() {
		return data.toString() + ":";
	}
}
