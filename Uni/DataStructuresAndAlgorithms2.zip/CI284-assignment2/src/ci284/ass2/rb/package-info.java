/**
 * Use this package for the classes which form the basis of your implementation of Red-Black trees. 
 * The classes required are:
 * 
 * . RBTree
 * . RBNode
 * . Nil
 * . RBTreeNode
 * 
 * See the assignment instructions for details.
 */
/**
 * @author jb259
 *
 */
package ci284.ass2.rb;