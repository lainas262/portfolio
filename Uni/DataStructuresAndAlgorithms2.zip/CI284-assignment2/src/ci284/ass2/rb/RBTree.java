/*
 * Author: Emmanouil Lainas
 * Reg.Num: 12847191
 * Data Structures & Algorithms Assignment 2
 */
package ci284.ass2.rb;
import ci284.ass2.rb.RBNode;

public class RBTree {
	
	public enum RBColour{
		RED,BLACK
	}
	
	private RBNode root=Nil.getNil();
	
	
	public RBNode getRoot(){
		return root;
	}
	
	public void setRoot(RBNode r){
		this.root=r;
	}
	
	public boolean find(Integer e){
		boolean flag = false;
		RBTreeNode x = (RBTreeNode) this.getRoot();

		if ( getRoot()!=Nil.getNil() ){
			while ( !flag ){
				if (x.getLabel() == e)
					flag= true;
				if (x.getLabel() < e ){
					x = (RBTreeNode) x.getRight();
				}
				if (x.getLabel() > e ){
					x = (RBTreeNode) x.getLeft();
				}
			}
		}
		return flag;
	}
	
	public void insert(Integer e){
		RBNode z= new RBTreeNode(e, null);
		RBNode y =new Nil();
 		RBNode x = root;
		RBNode nil = new Nil();
		
		while(x==Nil.getNil()){
			y=x;
			
			if (((RBTreeNode) z).getLabel()<((RBTreeNode) x).getLabel())
				x = x.getLeft();
			else
				x = x.getRight();
		}
		
		z.setParent(y);
		if (y ==Nil.getNil())
			root = z;
		else if (((RBTreeNode) z).getLabel() < ((RBTreeNode) y).getLabel())
			y.setLeft(z);
		else
			y.setRight(z);
		z.setLeft(Nil.getNil());
		z.setRight(Nil.getNil());
		z.setColour(RBColour.RED);
		fixupInsert(z);

	}
	
	public void delete(Integer e){
		
		RBNode z= new RBTreeNode(e, null);
		RBNode y = z;
		RBNode x =new Nil();
		RBColour ORIG = y.getColour();
			if( z.getLeft() == Nil.getNil()){
				x = z.getRight();
				transplant(z, z.getRight());
			}	
			else if(z.getRight() == Nil.getNil()){
				x = z.getLeft();
				transplant(z, z.getLeft());
			}
			else{
				y = minimum(z.getRight());
				ORIG = y.getColour();
				x = y.getRight();
				if( y.getParent() == z ){
					x.setParent(y);
				}	
				else {
					transplant(y, y.getRight());
					y.setRight(z.getRight());
					y.getRight().setParent(y);
				}
				transplant( z, y);
				y.setLeft(z.getLeft());
				y.getLeft().setParent(y);
				y.setColour(z.getColour());
			}	
			if(ORIG == RBColour.BLACK)
				fixupDelete(x);
	}
	
	public void fixupInsert(RBNode z){
		
		while (z.getParent().getColour() == RBColour.RED){
			if(z.getParent()==z.getParent().getParent().getLeft()){
				RBNode y = z.getParent().getParent().getRight();
				
				if(y.getColour() == RBColour.RED){
					z.getParent().setColour(RBColour.BLACK);
					y.setColour(RBColour.BLACK);
					z.getParent().getParent().setColour(RBColour.RED);
					z=z.getParent().getParent();
				}
				else if (z == z.getParent().getRight()){
						z=z.getParent();
						rotateLeft((RBTreeNode) z);
					}
					z.getParent().setColour(RBColour.BLACK);
					z.getParent().getParent().setColour(RBColour.RED);
					rotateRight((RBTreeNode) z.getParent().getParent());
			}
			else {
					RBNode y = z.getParent().getParent().getLeft();
					
					if(y.getColour() == RBColour.RED){
						z.getParent().setColour(RBColour.BLACK);
						y.setColour(RBColour.BLACK);
						z.getParent().getParent().setColour(RBColour.RED);
						z=z.getParent().getParent();
					}
					else{
						if (z == z.getParent().getLeft()){
							z=z.getParent();
							rotateLeft((RBTreeNode) z);
						}
						z.getParent().setColour(RBColour.BLACK);
						z.getParent().getParent().setColour(RBColour.RED);
						rotateRight((RBTreeNode) z.getParent().getParent());
					}
			}
		}
		root.setColour(RBColour.BLACK);
	}
	
	public void fixupDelete(RBNode x){
			RBNode w = new Nil();
		while (x ==root && x.getColour() == RBColour.BLACK){
			if (x == x.getParent().getLeft()){
				w = x.getParent().getRight();
				if(w.getColour() == RBColour.RED){
					w.setColour(RBColour.BLACK);
					x.getParent().setColour(RBColour.RED);
					rotateLeft((RBTreeNode) x.getParent());
					w = x.getParent().getRight();
				}
				if (w.getLeft().getColour() == RBColour.BLACK && 
					w.getRight().getColour() == RBColour.BLACK)
						w.setColour(RBColour.RED);
				else{
					if (w.getRight().getColour() == RBColour.BLACK){
						w.getLeft().setColour(RBColour.BLACK);
						w.setColour(RBColour.RED);
						rotateRight((RBTreeNode) w);
						w = x.getParent().getRight();
					}
					w.setColour(x.getParent().getColour());
					x.getParent().setColour(RBColour.BLACK);
					w.getRight().setColour(RBColour.BLACK);
					rotateLeft((RBTreeNode) x.getParent());
					x = root;
				}
			}
			else{
				w = x.getParent().getRight();
				if(w.getColour() == RBColour.RED){
					w.setColour(RBColour.BLACK);
					x.getParent().setColour(RBColour.RED);
					rotateLeft((RBTreeNode) x.getParent());
					w = x.getParent().getRight();
				}
				if (w.getLeft().getColour() == RBColour.BLACK && 
					w.getRight().getColour() == RBColour.BLACK)
					w.setColour(RBColour.RED);
				else{
					if (w.getRight().getColour() == RBColour.BLACK){
						w.getLeft().setColour(RBColour.BLACK);
						w.setColour(RBColour.RED);
						rotateRight((RBTreeNode) w);
						w = x.getParent().getRight();
					}
					w.setColour(x.getParent().getColour());
					x.getParent().setColour(RBColour.BLACK);
					w.getRight().setColour(RBColour.BLACK);
					rotateLeft((RBTreeNode) x.getParent());
					x = root;
				}
			}
		}
		x.setColour(RBColour.BLACK);
	}
	
	public void rotateLeft(RBTreeNode n){
		
		RBNode y=n.getRight();
		y.setRight(n.getLeft());
		
		if (y.getLeft()!= Nil.getNil()){
			y.getLeft().setParent(n);
		}
		
		y.setParent(n.getParent());
		if(n.getParent()==Nil.getNil()){
			root=y;
		}
		else if (n==n.getParent().getLeft()){
			n.getParent().setLeft(y);
		}
		else{
			n.getParent().setRight(y);
		}
		
		y.setLeft(n);
		n.setParent(y);
	}
	
	public void rotateRight(RBTreeNode n){
		
		RBNode y=n.getLeft();
		RBNode nil=new Nil();
		
		y.setLeft(n.getRight());
		
		if (y.getRight()!= nil){
			y.getRight().setParent(n);
		}
		
		y.setParent(n.getParent());
		if(n.getParent()==nil){
			root=y;
		}
		else if (n==n.getParent().getRight()){
			n.getParent().setRight(y);
		}
		else{
			n.getParent().setLeft(y);
		}
		
		y.setRight(n);
		n.setParent(y);
	}
	
	public void transplant(RBNode u, RBNode v){
		if(u.getParent()==Nil.getNil())
			root=v;
		else if (u==u.getParent().getLeft())
			u.getParent().setLeft(v);
		else
			u.getParent().setRight(v);
		v.setParent(u.getParent());
	}
	
	public RBNode minimum(RBNode x){
		while(x.getLeft()!=Nil.getNil())
			x=x.getLeft();
		return x;
	}
}
