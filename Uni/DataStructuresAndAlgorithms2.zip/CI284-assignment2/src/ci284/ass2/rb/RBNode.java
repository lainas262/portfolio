/*
 * Author: Emmanouil Lainas
 * Reg.Num: 12847191
 * Data Structures & Algorithms Assignment 2
 */
package ci284.ass2.rb;

public abstract class RBNode{
	
	private RBTree.RBColour colour;
	private RBNode parent;
	private RBNode left;
	private RBNode right;

	
	public abstract int height();

	public RBTree.RBColour getColour(){
		return colour;
	}
	
	public void setColour(RBTree.RBColour c){
		this.colour=c;
	}
	
	public RBNode getParent(){
		return parent;
	}
	
	public void setParent(RBNode p){
		this.parent=p;
	}
	
	public RBNode getLeft(){
		return left;
	}
	public RBNode getRight(){
		return right;
	}
	
	public void setLeft(RBNode l){
		this.left=l;
	}
	
	public void setRight(RBNode r){
		this.right=r;
	}
}
