/*
 * Author: Emmanouil Lainas
 * Reg.Num: 12847191
 * Data Structures & Algorithms Assignment 2
 */

package ci284.ass2.rb;

public class RBTreeNode extends RBNode{
	
	private Integer label;
	
	public RBTreeNode(Integer label, RBNode parent){
		this.label=label;
		setLeft(Nil.getNil());
		setRight(Nil.getNil());
		setParent(parent);
	}
	

	public int height(){
		int lh = ( getLeft() == Nil.getNil() ) ? 0 : getLeft().height ();
		int rh = ( getRight() == Nil.getNil() ) ? 0 : getRight().height ();
		return 1 + Math.max (lh , rh);
		}

	
	
	public Integer getLabel(){
		
		return label;
	}
	
	
	public String toString () {
		if ( label == null ) {
		return " null " ;
		} else {
		String cStr = ( getColour () == null ) ? " " : getColour ()
		. toString () . substring (0 , 1) ;
		String suffix = " [ " + cStr + " ] " ;
		return label . toString () + suffix ;
		}
		}

}
