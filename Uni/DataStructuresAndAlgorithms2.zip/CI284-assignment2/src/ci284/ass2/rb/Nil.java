/*
 * Author: Emmanouil Lainas
 * Reg.Num: 12847191
 * Data Structures & Algorithms Assignment 2
 */
package ci284.ass2.rb;

import ci284.ass2.rb.RBTree.RBColour;

public class Nil extends RBNode{
	
	private static Nil nil;
	
	public Nil(){
		setColour(RBTree.RBColour.BLACK);
	}
	
	public RBNode getLeft(){
		return nil;
	}
	
	public RBNode getRight(){
		return nil;
	}
	

	public static Nil getNil(){
		if (nil == null){
			nil = new Nil();
		}
		return nil;
		}
	
	
	public int height(){
		return 1;
	}

	public String toString () {
		return " * " ;
		}

}
