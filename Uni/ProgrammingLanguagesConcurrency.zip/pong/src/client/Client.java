package client;

import common.*;
import static common.Global.*;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

/**
 * Start the client that will display the game for a player
 */
class Client
{
	public boolean MCFlag = false;
	private NetMCReader theIn;
	private C_PongModel theModel;
	private GameObject ball;
	private GameObject bats[];

	public static void main( String args[] )
	{
		( new Client() ).start();
	}

	/**
	 * Start the Client
	 */
	public void start()
	{
		DEBUG.set( true );
		DEBUG.trace( "Pong Client" );
		DEBUG.set( false );
		C_PongModel       model = new C_PongModel();
		C_PongView        view  = new C_PongView();
		C_PongController  cont  = new C_PongController( model, view );
		
		//Check what the clients want to do, if play then makecontactwithserver
		//if watch the game new method broadcastGame()
		Scanner in = new Scanner(System.in);
		System.out.println("Type 'play' to play or 'broadcast' to view a game being played");
		String input;
		input = in.nextLine();
		System.out.println("You entered "+input);
		
		while(true){
			
			if(input.equals("play")){
				makeContactWithServer( model, cont );
				break;
			}
			else if(input.equals("broadcast")){
				broadcastGame(model);
				break;
			}
			System.out.println("Wrong argument entered. Arguments used are " +
					"'play' or 'broadcast'. Try again:");
			input = in.nextLine();
		
			
		}		
		in.close();
		model.addObserver( view );       // Add observer to the model
		view.setVisible(true);           // Display Screen
	}

	/**
	 * Make contact with the Server who controls the game
	 * Players will need to know about the model
	 *
	 * @param model Of the game
	 * @param cont Controller (MVC) of the Game
	 */
	public void makeContactWithServer( C_PongModel model,
			C_PongController  cont )
	{
		// Also starts the Player task that get the current state
		//  of the game from the server
		try
		{
			System.out.println("Connecting to game Server");
			Socket socket = new Socket( HOST, PORT ); //Socket
			Player thread = new Player(model, socket);
			cont.addPlayer(thread);
			new Thread(thread).start();

		}

		catch ( Exception e )
		{
			System.out.println("Error: " + e.getMessage() );
		}

	}
	
	public void broadcastGame(C_PongModel model){
			System.out.println("Receiving game currently being played");
			theModel = model;
			GameViewer gameViewer = new GameViewer(model);
			new Thread(gameViewer).start();
	
	}
	
}
