package client;

import common.*;
import static common.Global.*;
import java.io.*;

import java.net.Socket;
/**
 * Individual player run as a separate thread to allow
 * updates immediately the bat is moved
 */
class GameViewer implements Runnable
{
	private NetMCReader theMCIn; //Input Multicast stream
	private C_PongModel theModel;
	private GameObject ball;
	private GameObject bats[];

  /**
   * Constructor
   * @param model - model of the game
   * @param s - Socket used to communicate with server
   */
	
	
  public GameViewer( C_PongModel model)
  {
    // The game viewer needs to know this to be able to work
	  theModel = model;
	  try {
		  theMCIn = new NetMCReader(MCWPORT, MCA);
	  }
	  catch (IOException e){
		  System.out.println("Error: " + e.getMessage() );
	  }
  }
  
  
  public void processData(String s){
	  
	  	
	  	String state = s;
	  	String [] temp;								
		double array[] = new double[7];				
		temp = state.split(" ");					

		for(int i =0; i < temp.length ; i++)		
		{
			array[i] = Double.parseDouble(temp[i]);	
		}

		if(array[6]==1.0)
		{
			// update model
			ball = theModel.getBall();					
			bats = theModel.getBats();					

			ball.setX( array[0] );						
			ball.setY( array[1] );						
			bats[0].setX(array[2]);						
			bats[0].setY(array[3]);						
			bats[1].setX(array[4]);						
			bats[1].setY(array[5]);						
		}
	}
  
  
  /**
   * Get and update the model with the latest bat movement
   * sent by the server
   */
  public void run()                             // Execution
  {
    // Listen to network to get the latest state of the
    //  game from the server
    // Update model with this information, Redisplay model
	
	try {  
	  while(true) {  
		  String state = theMCIn.get();
		  if ( state==null ){
			  break;
		  }	  
		  processData(state);
		  theModel.modelChanged();
	  }
	  theMCIn.close();
	  
	}
	catch (IOException e){
		System.out.println(e.getMessage());
	}
	  
   // DEBUG.trace( "Player.run" );
  }
}

