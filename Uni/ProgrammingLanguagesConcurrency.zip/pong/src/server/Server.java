package server;
import java.io.IOException;
import java.net.*;
import static common.Global.*;
import common.*;

/**
 * Start the game server
 *  The call to makeActiveObject() in the model
 *   starts the play of the game
 */
class Server
{
	private NetObjectWriter p0, p1;
	private ServerSocket serverSocket;
	private Socket clientSocket;
	private int gameId=0;

	public static void main( String args[] )
	{
		( new Server() ).start();
	}

	/**
	 * Start the server
	 */
	public void start()
	{
		DEBUG.set( true );
		DEBUG.trace("Pong Server");
		DEBUG.set( false );               // Otherwise lots of debug info

		try
		{
			serverSocket = new ServerSocket(PORT); //Server Socket
		}
		catch ( IOException e )
		{
			System.out.println(e.getMessage());
		}
			//To allow multiple games 
			while(true){
				S_PongModel model = new S_PongModel();

				makeContactWithClients( model );
				gameId++;
				S_PongView  view  = new S_PongView(p0, p1, gameId);
									new S_PongController( model, view );
				model.addObserver( view );       // Add observer to the model
				model.makeActiveObject();        // Start play
			}
			
	}

	/**
	 * Make contact with the clients who wish to play
	 * Players will need to know about the model
	 * @param model  Of the game
	 */
	public void makeContactWithClients( S_PongModel model )
	{
		try{
			Player thread1 = null;
			Player thread2 = null;

			System.out.println("Waiting for client...");
			clientSocket = serverSocket.accept(); // Wait for connection
			System.out.println("Client connected.");
			thread1 = new Player(0, model, clientSocket); // Create thread
			p0 = thread1.getWrite();

			System.out.println("Waiting for client...");
			clientSocket = serverSocket.accept(); // Wait for connection
			System.out.println("Client connected.");
			thread2 = new Player(1, model, clientSocket);
			p1 = thread2.getWrite();

			new Thread(thread1).start(); // Start thread
			new Thread(thread2).start();
		}
		catch ( Exception e )
		{
			System.out.printf("Server.process(): %s\n",
					e.getMessage() );
		}
	}
	
}


