package server;

import java.io.IOException;
import java.net.Socket;

import common.DEBUG;
import common.NetMCWriter;
import common.NetObjectReader;
import common.NetObjectWriter;

/**
 * Individual player run as a separate thread to allow
 * updates to the model when a player moves there bat
 */
class Player implements Runnable
{

	private Socket theSocket; //Socket used
	private NetObjectReader theIn; //Input object stream
	private NetObjectWriter theOut; //Output object stream
//	private NetMCWriter theMCOut;
	private S_PongModel theModel;
	private int aPlayer;

	/**
	 * Constructor
	 * @param player Player 0 or 1
	 * @param model Model of the game
	 * @param s Socket used to communicate the players bat move
	 */

	public Player( int player, S_PongModel model, Socket s  )
	{
		aPlayer = player;
		theModel = model;
		theSocket = s;

		try
		{									
			theOut = new NetObjectWriter(theSocket);			 		
			theIn = new NetObjectReader(theSocket);	
		} 
		catch (IOException e) 
		{							
			System.out.println(e.getMessage());					
		}
	}
	
	public NetObjectWriter getWrite()				
	{
		return theOut;								
	}
	
	public void processData(String s){
		
		String state = s;
		if(state.equals("UP")){				
			theModel.moveBatUp(aPlayer);
			DEBUG.trace( "server up" );		
		}
		else if(state.equals("DOWN")){		
			theModel.moveBatDown(aPlayer);			
			DEBUG.trace( "server down" );	
		}
	}


	/**
	 * Get and update the model with the latest bat movement
	 */
	public void run()                             // Execution
	{

		try {
			while (true)								
			{
				Object obj = theIn.get(); //From Client
				if ( obj == null ) break;
				String state = (String) obj; //To string
				System.out.println(state);

				

				processData(state);
				theModel.modelChanged();
		

			}
			theIn.close(); //Close Read
			theOut.close(); //Close Write
			theSocket.close(); //Close Socket
		}
		catch (IOException e){
			System.out.println(e.getMessage());
		}
	
	}
	
}