package com.BMW.entities;

//Emmanouil Lainas (12847191)

import java.io.Serializable;
//import java.util.Date;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.sql.*;
 
@Entity
@Table(name = "BMWEmployee")
@NamedQuery(name = "listBMWEmployees", query = "SELECT e FROM BMWEmployee e")
public class BMWEmployee implements Serializable {
 
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue
    @Column(name = "EMPNO")
    @NotNull
    private Integer id;
 
    @Column(name = "EFULLNAME", length = 30)
    private String fullName;
 
    @Column(name = "JOB", length = 9)
    private String job;
 
    @Column(name = "MGR")
    private Integer mgr;
 
    @Column(name = "HIREDATE", length = 10)
    private Date hireDate;
 
    @Column(name = "SAL")
    private double salary;
 
    @Column(name = "COMM")
    private double commission;
   
    @Column(name = "DEPTNO")
    @NotNull
    private Integer departmentNo;
 
    
  
/*
 * We do not really need the setId method because the annotations @Id and @GeneratedValue
 * that are used take responsibility of creating a uniquely auto-generated value to represent
 * the Id of an Employee which will be the Primary key of the EMP table. 
 */
    public Integer getId() {
        return id;
    }
    public String getFullName() {
        return fullName;
    }
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    public String getJob() {
        return job;
    }
    public void setJob(String job){
    	this.job = job;
    }
    public Integer getMgr() {
        return mgr;
    }
    public void setMgr(Integer mgr){
    	this.mgr = mgr;
    }
    public Date getHireDate(){
    	return hireDate;
    }
    public void setHireDate(Date hireDate){
    	this.hireDate = hireDate;
    }
    public double getSalary(){
    	return salary;
    }
    public void setSalary(double salary){
    	this.salary = salary;
    }
    public double getCommission(){
    	return commission;
    }
    public void setCommission(double commission){
    	this.commission = commission;
    }
    public Integer getDepartmentNo(){
    	return departmentNo;
    }
    public void setDepartmentNo(Integer departmentNo){
    	this.departmentNo = departmentNo;
    }
}