package com.BMW.business.impl;

//Emmanouil Lainas (12847191)

import java.util.*;
import javax.ejb.Stateless;
import javax.persistence.*;

import com.BMW.business.BMWEmployeeRemote;
import com.BMW.entities.BMWEmployee;

/**
 * Session Bean implementation class ManageEmployeeBean
 */
@Stateless
public class BMWManageEmployeeBean implements BMWEmployeeRemote {
	
	@PersistenceContext(unitName = "BMWemp")
    private EntityManager entityManager;
 
    public BMWManageEmployeeBean() {
 
    }
    public List<BMWEmployee> listAllEmployees() {
    	TypedQuery<BMWEmployee> query = entityManager.createNamedQuery("listBMWEmployees", BMWEmployee.class);
    	return query.getResultList();
    }
    public BMWEmployee findEmployeeById(Integer id){
    	return entityManager.find(BMWEmployee.class, id);
    }
    public BMWEmployee addEmployee(BMWEmployee employee) {
        entityManager.persist(employee);
        return employee;
    }
    public void deleteEmployee(BMWEmployee employee){
    	entityManager.remove(entityManager.merge(employee));
    }
    public BMWEmployee updateEmployee(BMWEmployee employee){
    	return entityManager.merge(employee);
    }
}
