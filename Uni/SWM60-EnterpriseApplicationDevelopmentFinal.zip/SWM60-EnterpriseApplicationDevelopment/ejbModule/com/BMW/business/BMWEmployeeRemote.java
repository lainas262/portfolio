package com.BMW.business;

//Emmanouil Lainas (12847191)

import javax.ejb.Remote;

import com.BMW.entities.BMWEmployee;

import java.util.*;

@Remote
public interface BMWEmployeeRemote {
	
	List<BMWEmployee> listAllEmployees();
//	public boolean addEmployee(Employee employee);
	BMWEmployee addEmployee(BMWEmployee employee);

    BMWEmployee findEmployeeById(Integer id);

    void deleteEmployee(BMWEmployee employee);

    BMWEmployee updateEmployee(BMWEmployee employee);
}
