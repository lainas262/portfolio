package com.AWC.business;

//Emmanouil Lainas (12847191)

import javax.ejb.Remote;

import com.AWC.entities.AWCEmployee;


import java.util.*;

@Remote
public interface AWCEmployeeRemote {
	List<AWCEmployee> listAllEmployees();
//	public boolean addEmployee(Employee employee);
	AWCEmployee addEmployee(AWCEmployee employee);

    AWCEmployee findEmployeeById(Integer id);

    void deleteEmployee(AWCEmployee employee);

    AWCEmployee updateEmployee(AWCEmployee employee);
}
