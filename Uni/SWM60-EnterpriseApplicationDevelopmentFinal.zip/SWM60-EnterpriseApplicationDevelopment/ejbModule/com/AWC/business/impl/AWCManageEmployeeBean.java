package com.AWC.business.impl;

//Emmanouil Lainas (12847191)

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import com.AWC.business.AWCEmployeeRemote;
import com.AWC.entities.AWCEmployee;

/**
 * Session Bean implementation class AWCManageEmployeeBean
 */
@Stateless
public class AWCManageEmployeeBean implements AWCEmployeeRemote {

	@PersistenceContext(unitName = "AWCemp")
    private EntityManager entityManager;
 
    public AWCManageEmployeeBean() {
 
    }
 
    public List<AWCEmployee> listAllEmployees() {
    	TypedQuery<AWCEmployee> query = entityManager.createNamedQuery("listAWCEmployees", AWCEmployee.class);
    	return query.getResultList();
    }
    
    public AWCEmployee findEmployeeById(Integer id){
    	return entityManager.find(AWCEmployee.class, id);
    }
    
    
    public AWCEmployee addEmployee(AWCEmployee employee) {
        entityManager.persist(employee);
        return employee;
    }
    
    public void deleteEmployee(AWCEmployee employee){
    	entityManager.remove(entityManager.merge(employee));
    }
    
    public AWCEmployee updateEmployee(AWCEmployee employee){
    	return entityManager.merge(employee);
    }

}
