package com.AWC.entities;

//Emmanouil Lainas (12847191)

import java.sql.Date;
import java.io.Serializable;

import javax.persistence.*;
import javax.validation.constraints.*;
import javax.validation.constraints.NotNull;


@Entity
@Table(name = "AWCEmployee")
@NamedQuery(name = "listAWCEmployees", query = "SELECT f FROM AWCEmployee f")
public class AWCEmployee implements Serializable {
	

	private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue
    @Column(name = "EmployeeID")
    @NotNull
    private Integer id;
 
    @Column(name = "NationalIDNumber", length = 15)
    private String nationalIDNo;
    
    @Column(name = "ContactID")
    private Integer contactID;
    
    @Column(name = "LoginID", length = 256)
    private String loginID;
    
    @Column(name = "ManagerID")
    private Integer managerID;
    
    @Column(name = "Title", length = 50)
    private String title;
    
    @Column(name = "BirthDate", length = 10)
    private Date birthDate;
    
    @Column(name = "MaritalStatus")
    private Character maritalStatus;
    
    @Column(name = "Gender")
    private Character gender;
    
    @Column(name = "HireDate", length = 10)
    private Date hireDate;
    
    @Column(name = "SalariedFlag")
    private Character salariedFlag;
    
    @Column(name = "VacationHours")
    @Min(-40)
    @Max(240)
    private Short vacationHrs;
    
    @Column(name = "SickLeaveHours")
    @Min(0)
    @Max(120)
    private Short sickLeaveHrs;
    
    @Column(name = "CurrentFlag")
    private Character currentFlag;
    
    @Column(name = "ModifiedDate", length = 15)
    private Date modifiedDate;
    
 
	
    
  
/*
 * We do not really need the setId method because the annotations @Id and @GeneratedValue
 * that are used take responsibility of creating a uniquely auto-generated value to represent
 * the Id of an Employee which will be the Primary key of the EMP table. 
 */
	
//get set ID
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
//get set NationalIdNo
    public String getNationalIDNo() {
        return nationalIDNo;
    }
    public void setNationalIDNo(String nationalIDNo) {
        this.nationalIDNo = nationalIDNo;
    }
//get set ContactIDNo
    public Integer getContactID() {
        return contactID;
    }
    public void setContactID(Integer contactID){
    	this.contactID = contactID;
    }
//get set LoginId
    public String getLoginID() {
        return loginID;
    }
    public void setLoginID(String loginID){
    	this.loginID = loginID;
    }
//get set ManagerId
    public Integer getManagerID(){
    	return managerID;
    }
    public void setManagerID(Integer managerID){
    	this.managerID = managerID;
    }
//get set Title
    public String getTitle(){
    	return title;
    }
    public void setTitle(String title){
    	this.title = title;
    }
//get set BirthDate
    public Date getBirthDate(){
    	return birthDate;
    }
    public void setBirthDate(Date birthDate){
    	this.birthDate = birthDate;
    }
 //get set Marital Status
    public Character getMaritalStatus(){
    	return maritalStatus;
    }
    public void setMaritalStatus(Character maritalStatus){
    	this.maritalStatus = maritalStatus;
    }
//get set Gender
    public Character getGender(){
    	return gender;
    }
    public void setGender(Character gender){
    	this.gender = gender;
    }
//get set Hire Date
    public Date getHireDate(){
    	return hireDate;
    }
    public void setHireDate(Date hireDate){
    	this.hireDate = hireDate;
    }
//get set SalariedFlag
    public Character getSalariedFlag(){
    	return salariedFlag;
    }
    public void setSalariedFlag(Character salariedFlag){
    	this.salariedFlag = salariedFlag;
    }
//get set VacationHrs
    public Short getVacationHrs(){
    	return vacationHrs;
    }
    public void setVacationHrs(Short vacationHrs){
    	this.vacationHrs = vacationHrs;
    }
//get set SickLeaveHrs
    public Short getSickLeaveHrs(){
    	return sickLeaveHrs;
    }
    public void setSickLeaveHrs(Short sickLeaveHrs){
    	this.sickLeaveHrs = sickLeaveHrs;
    }
//get set ModifiedDate
    public Date getModifiedDate(){
    	return modifiedDate;
    }
    public void setModifiedDate(Date modifiedDate){
    	this.modifiedDate = modifiedDate;
    }
//get set current   
    public Character getCurrentFlag(){
    	return currentFlag;
    }
    public void setCurrentFlag(Character currentFlag){
    	this.currentFlag = currentFlag;
    } 
    
   
}
