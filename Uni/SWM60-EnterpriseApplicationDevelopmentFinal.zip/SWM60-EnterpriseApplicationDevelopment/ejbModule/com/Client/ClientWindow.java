package com.Client;

//Emmanouil Lainas (12847191)

import com.AWC.business.AWCEmployeeRemote;
import com.AWC.entities.AWCEmployee;
import com.BMW.business.BMWEmployeeRemote;
import com.BMW.entities.BMWEmployee;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*; 
import java.awt.EventQueue;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.GridLayout;

import javax.swing.border.LineBorder;

import java.awt.Color;

import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JComboBox;


public class ClientWindow extends JFrame {

	private static final long serialVersionUID = 1L;//or some long
	
	private JPanel contentPane;
	int delay = 5000;
//BMW Data Global graphics elements that are used for the flow of the program
	private JTextField BMWempIDtextField;	
	private JTextField BMWfullNameTextField;	
	private JTextField BMWjobTextField;
	private JTextField BMWmanagerIdTextField;
	private JTextField BMWhireDateTextField;
	private JTextField BMWsalaryTextField;
	private JTextField BMWcommissionTextField;
	private JTextField BMWdeptNoTextField;
	private JLabel BMWretrievedEmpIdLabel;
	private JTable BMWemployeeTable;
	private List<BMWEmployee> bmwEmps;
	private String[][] bmwEmpArray;
	private JScrollPane BMWscrollPane;
	BMWEmployeeRemote BMWremote = doBMWLookup();
	BMWEmployee BMWemployee;
	private DateFormat BMWdateFormat = new SimpleDateFormat("yyyy-MM-dd");
	private String BMWstringDate;
	java.sql.Date BMWdate;
	private String[] BMWtableColumnNames = new String[] {"Employee ID No.", "Full Name", "Job", "Manager ID No.", "Hire Date", "Salary", "Commission", "Department No."};
	private DefaultTableModel bmwData = new DefaultTableModel(updateBMWTable(), BMWtableColumnNames);
	
	
	
//AWC Data Global graphics elements that are used for the flow of the program
	private JTextField AWCempIDtextField;
	private JLabel AWCretrievedEmpIDLabel;
	private JTextField AWCNationalIDTextField;
	private JTextField AWCcontactIDTextField;
	private JTextField AWCloginIDTextField;
	private JTextField AWCmanagerIDTextField;
	private JTextField AWCtitleTextField;
	private JTextField AWCbirthDateTextField;
	private JTextField AWChireDateTextField;
    private JTextField AWCvacationHrsTextField;
    private JTextField AWCsickleaveHrsTextField;
	private JComboBox<String> AWCmaritalStatuscomboBox;
	private JComboBox<String> AWCgendercomboBox;
	private JComboBox<String> AWCsalariedcomboBox;
	private JComboBox<String> AWCcurrentComboBox;
	private JLabel AWCmodifiedDateLabelResult;
	private JTable AWCemployeeTable;
	private List<AWCEmployee> awcEmps;
	private String[][] awcEmpArray;
	private JScrollPane AWCscrollPane;
	AWCEmployeeRemote AWCremote = doAWCLookup();
	AWCEmployee AWCemployee;
	private DateFormat AWCdateFormat = new SimpleDateFormat("yyyy-MM-dd");
	private String AWCstringDate;
	java.sql.Date AWCdate;
	private String[] AWCtableColumnNames = new String[] {"Employee ID No.", "National ID No.", "Contact ID", 
			"Login ID", "Manager ID", "Title", "Birth Date", "Marital Status", "Gender", "Hire Date", "Salaried", 
			"VacationHrs", "Sick Leave","Current", "Date Modified"};
	private DefaultTableModel awcData = new DefaultTableModel(updateAWCTable(), AWCtableColumnNames);
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClientWindow frame = new ClientWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ClientWindow() {
		setTitle("AWC-BMW");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1200, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(1, 2, 10, 0));		
//initialize the panel for each company
		contentPane.add(initializeBMWPanel());
		contentPane.add(initializeAWCPanel());
	}

	public JPanel initializeBMWPanel(){
		JPanel bmw = new JPanel();
		bmw.setBorder(new TitledBorder(new LineBorder(new Color(255, 0, 0), 2, true), "BMWFahrradManufaktur", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		bmw.setLayout(new GridLayout(3, 1, 0, 10));		
//add three panels to represent the buttons, Form, and result table of BMW
		bmw.add(initializeBMWButtonPanel());
		bmw.add(initializeBMWFormPanel());
		bmw.add(initializeBMWTableScrollPane());
		return bmw;
	}
	
	public JPanel initializeAWCPanel(){
		JPanel awc = new JPanel();
		awc.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(0, 0, 255), null), "Adventure Works Cycles", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		awc.setLayout(new GridLayout(3, 1, 0, 10));
//add three panels to represent the buttons, Form, and result table of AWC
		awc.add(initializeAWCButtonPanel());
		awc.add(initilizeAWCFormPanel());
		awc.add(initializeAWCTableScrollPane());
		return awc;
	}
	
//The next two method initialize the Button Panels of each company
	public JPanel initializeBMWButtonPanel(){
		JPanel bmwButtonPanel = new JPanel();
		bmwButtonPanel.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Tools", TitledBorder.LEADING, TitledBorder.TOP, null, Color.GRAY));
		
		bmwButtonPanel.setLayout(new GridLayout(2, 2, 20, 20));
		
		JButton BMWsearchEmployee = new JButton("Search Employee By ID");
//actionListener for the "Search Employee By ID" button of BMW		
		BMWsearchEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showBMWEmployeeDetails();
			}
		});
		bmwButtonPanel.add(BMWsearchEmployee);
		BMWempIDtextField = new JTextField();
		BMWempIDtextField.setFont(new Font("Tahoma", Font.ITALIC, 14));
		BMWempIDtextField.setText("Type Employee ID Here");
		BMWempIDtextField.setHorizontalAlignment(SwingConstants.CENTER);
		BMWempIDtextField.setToolTipText("Type Employee ID Here");
		bmwButtonPanel.add(BMWempIDtextField);
		BMWempIDtextField.setColumns(10);
		
		JButton BMWbtnTransferEmployeeToAWC = new JButton("Transfer Employee to AWC");
		bmwButtonPanel.add(BMWbtnTransferEmployeeToAWC);
		return bmwButtonPanel;
	}
	
	public JPanel initializeAWCButtonPanel(){
		JPanel awcButtonPanel = new JPanel();
		awcButtonPanel.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Tools", TitledBorder.LEADING, TitledBorder.TOP, null, Color.GRAY));
		
		awcButtonPanel.setLayout(new GridLayout(2, 2, 20, 20));
		
		JButton AWCsearchEmployee = new JButton("Search Employee By ID");
//actionListener for the "Search Employee By ID" button of AWC
		AWCsearchEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showAWCEmployeeDetails();
			}
		});
		awcButtonPanel.add(AWCsearchEmployee);
		
		AWCempIDtextField = new JTextField();
		AWCempIDtextField.setFont(new Font("Tahoma", Font.ITALIC, 14));
		AWCempIDtextField.setText("Type Employee ID Here");
		AWCempIDtextField.setHorizontalAlignment(SwingConstants.CENTER);
		AWCempIDtextField.setToolTipText("Type Employee ID Here");
		awcButtonPanel.add(AWCempIDtextField);
		AWCempIDtextField.setColumns(10);
		
		JButton AWCbtnTransferEmployeeToBMW = new JButton("Transfer Employee to BMW");
		awcButtonPanel.add(AWCbtnTransferEmployeeToBMW);
		return awcButtonPanel;
	}
	
//The next two methods initialise the Form Panels of each company (methods are long due to the many textbox elements loaded etc.)
	public JPanel initializeBMWFormPanel(){
		JPanel bmwFormPanel = new JPanel();
		bmwFormPanel.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "BMW Employee Form", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(128, 128, 128)));
		
		bmwFormPanel.setLayout(new GridLayout(10, 2, 2, 2));
		
		JLabel employeeIdLabel = new JLabel("Employee ID No.:");
		bmwFormPanel.add(employeeIdLabel);
		
		BMWretrievedEmpIdLabel = new JLabel("****");
		bmwFormPanel.add(BMWretrievedEmpIdLabel);
		
		JLabel BMWfullNameLabel = new JLabel("Full Name:");
		bmwFormPanel.add(BMWfullNameLabel);
		
		BMWfullNameTextField = new JTextField();
		BMWfullNameTextField.setToolTipText("Type Employee Name Here");
		bmwFormPanel.add(BMWfullNameTextField);
		BMWfullNameTextField.setColumns(10);
		
		JLabel BMWjobLabel = new JLabel("Job:");
		BMWjobLabel.setToolTipText("");
		bmwFormPanel.add(BMWjobLabel);
		
		BMWjobTextField = new JTextField();
		BMWjobTextField.setToolTipText("Type Job Description Here");
		bmwFormPanel.add(BMWjobTextField);
		BMWjobTextField.setColumns(10);
		
		JLabel BMWmanagerIdNoLabel = new JLabel("Manager ID No.:");
		bmwFormPanel.add(BMWmanagerIdNoLabel);
		
		BMWmanagerIdTextField = new JTextField();
		BMWmanagerIdTextField.setToolTipText("Type Manager Id No Here");
		bmwFormPanel.add(BMWmanagerIdTextField);
		BMWmanagerIdTextField.setColumns(10);
		
		JLabel BMWhireDateLabel = new JLabel("Hire Date:");
		bmwFormPanel.add(BMWhireDateLabel);
		
		BMWhireDateTextField = new JTextField();
		BMWhireDateTextField.setToolTipText("Type Hire Date Here (date format: YYYY-MM-DD)");
		BMWhireDateTextField.setText("");
		bmwFormPanel.add(BMWhireDateTextField);
		BMWhireDateTextField.setColumns(10);
		
		JLabel BMWsalaryLabel = new JLabel("Salary:");
		bmwFormPanel.add(BMWsalaryLabel);
		
		BMWsalaryTextField = new JTextField();
		BMWsalaryTextField.setToolTipText("Type Salary Here");
		bmwFormPanel.add(BMWsalaryTextField);
		BMWsalaryTextField.setColumns(10);
		
		JLabel BMWcommissionLabel = new JLabel("Commission:");
		bmwFormPanel.add(BMWcommissionLabel);
		
		BMWcommissionTextField = new JTextField();
		BMWcommissionTextField.setToolTipText("Type Commission Here");
		bmwFormPanel.add(BMWcommissionTextField);
		BMWcommissionTextField.setColumns(10);
		
		JLabel BMWdeptNoLabel = new JLabel("Department No.:");
		bmwFormPanel.add(BMWdeptNoLabel);
		
		BMWdeptNoTextField = new JTextField();
		BMWdeptNoTextField.setToolTipText("Type Department No Here");
		bmwFormPanel.add(BMWdeptNoTextField);
		BMWdeptNoTextField.setColumns(10);
		
		JButton BMWaddEmployeeButton = new JButton("Add Employee");
//actionListener for the "Add Employee" to add employees in BMW
		BMWaddEmployeeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addBMWEmployee();
			}
		});
		bmwFormPanel.add(BMWaddEmployeeButton);
		
		JButton BMWupdateEmployeeLabel = new JButton("Update Employee Record");
//actionListener for the "Update Employee Record" in BMW 
		BMWupdateEmployeeLabel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateBMWEmployeeRecord();
			}
		});
		BMWupdateEmployeeLabel.setToolTipText("Updated Employee Must be searched using ID No. before Update");
		bmwFormPanel.add(BMWupdateEmployeeLabel);
		
		JButton BMWdeleteEmployeeButton = new JButton("Delete Employee");
//actionListener for the "Delete Employee" to remove and employee from BMW
		BMWdeleteEmployeeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				deleteBMWEmployee();
			}
		});
		bmwFormPanel.add(BMWdeleteEmployeeButton);
		return bmwFormPanel;
	}

	public JPanel initilizeAWCFormPanel(){
		JPanel awcFormPanel = new JPanel();
		awcFormPanel.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "AWC Employee Form", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(128, 128, 128)));
		
		awcFormPanel.setLayout(new GridLayout(9, 4, 2, 2));
		
		JLabel AWCemployeeIdLabel = new JLabel("Employee ID No.:");
		awcFormPanel.add(AWCemployeeIdLabel);
		
		AWCretrievedEmpIDLabel = new JLabel("****");
		awcFormPanel.add(AWCretrievedEmpIDLabel);
		
		JLabel AWCNationalIDLabel = new JLabel("National ID No.:");
		awcFormPanel.add(AWCNationalIDLabel);
		
		AWCNationalIDTextField = new JTextField();
		AWCNationalIDTextField.setToolTipText("Type National ID No here");
		awcFormPanel.add(AWCNationalIDTextField);
		AWCNationalIDTextField.setColumns(10);
		
		JLabel AWCcontactIDLabel = new JLabel("Contact ID:");
		AWCcontactIDLabel.setToolTipText("");
		awcFormPanel.add(AWCcontactIDLabel);
		
		AWCcontactIDTextField = new JTextField();
		AWCcontactIDTextField.setToolTipText("Type Contact ID here");
		awcFormPanel.add(AWCcontactIDTextField);
		AWCcontactIDTextField.setColumns(10);
		
		JLabel AWCloginIDLabel = new JLabel("Login ID:");
		awcFormPanel.add(AWCloginIDLabel);
		
		AWCloginIDTextField = new JTextField();
		AWCloginIDTextField.setToolTipText("Type Login ID Here");
		awcFormPanel.add(AWCloginIDTextField);
		AWCloginIDTextField.setColumns(10);
		
		JLabel AWCManagerIDLabel = new JLabel("Manager ID No.:");
		awcFormPanel.add(AWCManagerIDLabel);
		
		AWCmanagerIDTextField = new JTextField();
		AWCmanagerIDTextField.setToolTipText("Type Manager ID here");
		AWCmanagerIDTextField.setText("");
		awcFormPanel.add(AWCmanagerIDTextField);
		AWCmanagerIDTextField.setColumns(10);
		
		JLabel AWCtitleLabel = new JLabel("Title:");
		awcFormPanel.add(AWCtitleLabel);
		
		AWCtitleTextField = new JTextField();
		AWCtitleTextField.setToolTipText("Type Title Here");
		awcFormPanel.add(AWCtitleTextField);
		AWCtitleTextField.setColumns(10);
		
		JLabel AWCbirthDateLabel = new JLabel("Birth Date:");
		awcFormPanel.add(AWCbirthDateLabel);
		
		AWCbirthDateTextField = new JTextField();
		AWCbirthDateTextField.setToolTipText("Type Birth Date Here (format: YYYY-MM-DD)");
		awcFormPanel.add(AWCbirthDateTextField);
		AWCbirthDateTextField.setColumns(10);
		
		JLabel AWCmaritalStatusLabel = new JLabel("Marital Status:");
		awcFormPanel.add(AWCmaritalStatusLabel);
		
		String[] maritalStatusOption = {"Married", "Single"};
		AWCmaritalStatuscomboBox = new JComboBox<>(maritalStatusOption);
		awcFormPanel.add(AWCmaritalStatuscomboBox);
		
		JLabel AWCgenderLabel = new JLabel("Gender");
		awcFormPanel.add(AWCgenderLabel);
		
		String[] genderOption = {"Male", "Female"};
		AWCgendercomboBox = new JComboBox<>(genderOption);
		awcFormPanel.add(AWCgendercomboBox);
		
		JLabel AWChireDateLabel = new JLabel("Hire Date:");
		awcFormPanel.add(AWChireDateLabel);
		
		AWChireDateTextField = new JTextField();
		AWChireDateTextField.setToolTipText("Type Hire Date here (format YYYY-MM-DD)");
		awcFormPanel.add(AWChireDateTextField);
		AWChireDateTextField.setColumns(10);
		
		JLabel AWCsalariedFlagLabel = new JLabel("Salaried:");
		awcFormPanel.add(AWCsalariedFlagLabel);
		
		String[] salariedOption = {"YES", "NO"};
		AWCsalariedcomboBox = new JComboBox<>(salariedOption);
		awcFormPanel.add(AWCsalariedcomboBox);
		
		JLabel AWCvacationHrsLabel = new JLabel("Vacation Hours:");
		AWCvacationHrsLabel.setToolTipText("");
		awcFormPanel.add(AWCvacationHrsLabel);
		
		AWCvacationHrsTextField = new JTextField();
		AWCvacationHrsTextField.setToolTipText("Type vacation hours here");
		awcFormPanel.add(AWCvacationHrsTextField);
		AWCvacationHrsTextField.setColumns(10);
		
		JLabel AWCsickleaveHrsLabel = new JLabel("Sick Leave Hours:");
		awcFormPanel.add(AWCsickleaveHrsLabel);
		
		AWCsickleaveHrsTextField = new JTextField();
		AWCsickleaveHrsTextField.setToolTipText("Type sick leave hours here");
		awcFormPanel.add(AWCsickleaveHrsTextField);
		AWCsickleaveHrsTextField.setColumns(10);
		
		JLabel AWCcurrentLabel = new JLabel("Current:");
		awcFormPanel.add(AWCcurrentLabel);
		
		String[] currentOption = {"YES", "NO"};
		AWCcurrentComboBox = new JComboBox<>(currentOption);
		awcFormPanel.add(AWCcurrentComboBox);

		JLabel AWCmodifiedDate = new JLabel("Modified Date:");
		awcFormPanel.add(AWCmodifiedDate);
		
		AWCmodifiedDateLabelResult = new JLabel("****");
		awcFormPanel.add(AWCmodifiedDateLabelResult);
		
		JLabel UNUSEDlblNewLabel = new JLabel("");
		awcFormPanel.add(UNUSEDlblNewLabel);
		
		JLabel UNUSEDlblNewLabel_1 = new JLabel("");
		awcFormPanel.add(UNUSEDlblNewLabel_1);
		
		JLabel UNUSEDlblNewLabel_2 = new JLabel("");
		awcFormPanel.add(UNUSEDlblNewLabel_2);
		
		JButton AWCaddEmployeeButton = new JButton("Add Employee");
//actionListener for "Add Employee" to add employee in AWC
		AWCaddEmployeeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addAWCEmployee();
			}
		});
		awcFormPanel.add(AWCaddEmployeeButton);
		
		JButton AWCupdateEmployeeButton = new JButton("Update Employee Record");
//actionListener for "Update Employee Record" to update employee in AWC
		AWCupdateEmployeeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateAWCEmployeeRecord();
			}
		});
		awcFormPanel.add(AWCupdateEmployeeButton);
		
		JButton AWCdeleteEmployeeButton = new JButton("Delete Employee");
//actionListener for "Delete Employee" to remove employee from AWC
		AWCdeleteEmployeeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				deleteAWCemployee();
			}
		});
		awcFormPanel.add(AWCdeleteEmployeeButton);
		
		return awcFormPanel;
	}
	
//the next two methods initialise the Tables of BMW and AWC
//the tables are updated every 5 seconds to provide each connected client an updated view
	public JScrollPane initializeBMWTableScrollPane(){
		
		BMWscrollPane = new JScrollPane();
		BMWemployeeTable = new JTable(){
	    
			private static final long serialVersionUID = 1L;

	        public boolean isCellEditable(int row, int column) {                
	                return false;               
	        };
	    };
		BMWemployeeTable.setRowSelectionAllowed(false);
		BMWemployeeTable.setModel(bmwData);
		BMWscrollPane.setViewportView(BMWemployeeTable);
		
		Timer timer1 = new Timer();
		TimerTask timerTask1 = new TimerTask(){
			public void run() {
				refreshBMWTable();				
			}				
		};
		timer1.scheduleAtFixedRate(timerTask1, 0 , 5 * 1000);
		
		return BMWscrollPane;
	
	}
	
	public JScrollPane initializeAWCTableScrollPane(){
		AWCscrollPane = new JScrollPane();
		AWCemployeeTable = new JTable(){
			private static final long serialVersionUID = 1L;

	        public boolean isCellEditable(int row, int column) {                
	                return false;               
	        };
		};
		AWCemployeeTable.setRowSelectionAllowed(false);
		AWCemployeeTable.setModel(awcData);
		AWCscrollPane.setViewportView(AWCemployeeTable);
		
		Timer timer2 = new Timer();
		TimerTask timerTask2 = new TimerTask(){
			public void run() {
				refreshAWCTable();				
			}				
		};
		timer2.scheduleAtFixedRate(timerTask2, 0 , 10 * 1000);
		
		return AWCscrollPane;
	}
	
//method called when the "Search Employee By ID" button is pressed for BMW
	public void showBMWEmployeeDetails(){
		try{
			//the bean is being looked up from the JNDI directory
			BMWremote = doBMWLookup();
			//instance of BMWemployee is being searched from the findEmployeeById() method
			//and when found the details are updated from the object retrieved to the form
			//If the employee is not found an Exception is thorwn and the search process must be repeted
			BMWemployee = BMWremote.findEmployeeById(Integer.parseInt(BMWempIDtextField.getText()));
			BMWretrievedEmpIdLabel.setText(Integer.toString(BMWemployee.getId()));
			BMWfullNameTextField.setText(BMWemployee.getFullName());
			BMWjobTextField.setText(BMWemployee.getJob());
			BMWmanagerIdTextField.setText(Integer.toString(BMWemployee.getMgr()));
			BMWstringDate = BMWdateFormat.format(BMWemployee.getHireDate());
			BMWhireDateTextField.setText(BMWstringDate);
			BMWsalaryTextField.setText(Double.toString(BMWemployee.getSalary()));
			BMWcommissionTextField.setText(Double.toString(BMWemployee.getCommission()));
			BMWdeptNoTextField.setText(Integer.toString(BMWemployee.getDepartmentNo()));
			BMWempIDtextField.setText("Type Employee ID Here");
		}catch(Exception e){
			BMWempIDtextField.setText("Type the Employee ID No. and then press Search");
		}
	}

//method called when the "Search Employee By ID" button is pressed for AWC
	public void showAWCEmployeeDetails(){
		try{
			//the bean is being looked up from the JNDI directory
			AWCremote = doAWCLookup();
			//instance of AWCemployee is being searched from the findEmployeeById() method
			//and when found the details are updated from the object retrieved to the form
			//If the employee is not found an Exception is thorwn and the search process must be repeted
			AWCemployee = AWCremote.findEmployeeById(Integer.parseInt(AWCempIDtextField.getText()));
			AWCretrievedEmpIDLabel.setText(Integer.toString(AWCemployee.getId()));
			AWCNationalIDTextField.setText(AWCemployee.getNationalIDNo());
			AWCcontactIDTextField.setText(Integer.toString(AWCemployee.getContactID()));
			AWCloginIDTextField.setText(AWCemployee.getLoginID());
			AWCmanagerIDTextField.setText(Integer.toString(AWCemployee.getManagerID()));
			AWCtitleTextField.setText(AWCemployee.getTitle());
			AWCstringDate = AWCdateFormat.format(AWCemployee.getBirthDate());
			AWCbirthDateTextField.setText(AWCstringDate);
			
			Character maritalValue = AWCemployee.getMaritalStatus();
			if(maritalValue=='M')
				AWCmaritalStatuscomboBox.setSelectedIndex(0);
			else
				AWCmaritalStatuscomboBox.setSelectedIndex(1);
			
			Character genderValue = AWCemployee.getGender();
			if(genderValue=='M')
				AWCgendercomboBox.setSelectedIndex(0);
			else
				AWCgendercomboBox.setSelectedIndex(1);
			
			AWCstringDate = AWCdateFormat.format(AWCemployee.getHireDate());
			AWChireDateTextField.setText(AWCstringDate);
			
			Character salariedValue = AWCemployee.getSalariedFlag();
			if(salariedValue=='Y')
				AWCsalariedcomboBox.setSelectedIndex(0);
			else
				AWCsalariedcomboBox.setSelectedIndex(1);
			
			AWCvacationHrsTextField.setText(Short.toString(AWCemployee.getVacationHrs()));
			AWCsickleaveHrsTextField.setText(Short.toString(AWCemployee.getSickLeaveHrs()));
			
			Character currentValue = AWCemployee.getCurrentFlag();
			if(currentValue=='Y')
				AWCcurrentComboBox.setSelectedIndex(0);
			else
				AWCcurrentComboBox.setSelectedIndex(1);
			
			AWCstringDate = AWCdateFormat.format(AWCemployee.getModifiedDate());
			AWCmodifiedDateLabelResult.setText(AWCstringDate);
			AWCempIDtextField.setText("Type Employee ID Here");
		}catch(Exception e){
			AWCempIDtextField.setText("Type the Employee ID No. and then press Search");
		}
	}
    
//method called when "Add Employee" button is pressed for BMW
	public void addBMWEmployee(){
		try{
			//new instance of BMW employee
			BMWemployee = new BMWEmployee();
			//values are set from the fields to the object with appropriate conversions
			BMWemployee.setFullName(BMWfullNameTextField.getText());
			BMWemployee.setJob(BMWjobTextField.getText());
			BMWemployee.setMgr(Integer.parseInt(BMWmanagerIdTextField.getText()));
			Date BMWdate = BMWdateFormat.parse(BMWhireDateTextField.getText());
			java.sql.Date BMWsqlDate = new java.sql.Date(BMWdate.getTime());
			BMWemployee.setHireDate(BMWsqlDate);
			BMWemployee.setSalary(Double.parseDouble(BMWsalaryTextField.getText()));
			BMWemployee.setCommission(Double.parseDouble(BMWcommissionTextField.getText()));
			BMWemployee.setDepartmentNo(Integer.parseInt(BMWdeptNoTextField.getText()));
			//the addEmployee method is called on the BMWremote ManageEmployee bean for the entity BMWemployee created
			//so that the BMWemployee entity will be persisted on the database
			BMWremote.addEmployee(BMWemployee);
			//form fields are cleared and the BMW table is refreshed to include the new Entry created
			clearBMWFormFields();
			refreshBMWTable();
			//Global variable BMWemployee is set to null for data flow purposes 
			BMWemployee = null;
		}catch(Exception e){
			//exception is thrown when incorrect data are inserted
			BMWempIDtextField.setText("Fields Must be Filled with the appropriate Data");
		}
	}

//method called when "Add Employee" button is pressed for AWC
	public void addAWCEmployee(){
		try{
			//the same process is carried as with BMW employee addition
			AWCemployee = new AWCEmployee();
			AWCemployee.setNationalIDNo(AWCNationalIDTextField.getText());
			AWCemployee.setContactID(Integer.parseInt(AWCcontactIDTextField.getText()));
			AWCemployee.setLoginID(AWCloginIDTextField.getText());
			AWCemployee.setManagerID(Integer.parseInt(AWCmanagerIDTextField.getText()));
			AWCemployee.setTitle(AWCtitleTextField.getText());
			Date AWCdate = AWCdateFormat.parse(AWCbirthDateTextField.getText());
			java.sql.Date AWCsqlDate = new java.sql.Date(AWCdate.getTime());
			AWCemployee.setBirthDate(AWCsqlDate);
			
			String maritalValue = (String)AWCmaritalStatuscomboBox.getSelectedItem();
			if(maritalValue=="Married")
				AWCemployee.setMaritalStatus('M');
			else
				AWCemployee.setMaritalStatus('S');
			
			String genderValue = (String)AWCgendercomboBox.getSelectedItem();
			if(genderValue=="Male")
				AWCemployee.setGender('M');
			else
				AWCemployee.setGender('F');
			
			AWCdate = AWCdateFormat.parse(AWChireDateTextField.getText());
			AWCsqlDate = new java.sql.Date(AWCdate.getTime());
			AWCemployee.setHireDate(AWCsqlDate);
			
			String salariedValue = AWCsalariedcomboBox.getSelectedItem().toString();
			if(salariedValue=="YES")
				AWCemployee.setSalariedFlag('Y');
			else
				AWCemployee.setSalariedFlag('N');
			
			AWCemployee.setVacationHrs(Short.parseShort(AWCvacationHrsTextField.getText()));
			AWCemployee.setSickLeaveHrs(Short.parseShort(AWCsickleaveHrsTextField.getText()));
			
			String currentValue = AWCcurrentComboBox.getSelectedItem().toString();
			if(currentValue=="YES")
				AWCemployee.setCurrentFlag('Y');
			else
				AWCemployee.setCurrentFlag('N');
			
			Calendar cal = Calendar.getInstance();
			AWCdate = cal.getTime();
			AWCsqlDate = new java.sql.Date(AWCdate.getTime());
			AWCemployee.setModifiedDate(AWCsqlDate);
			
			AWCremote.addEmployee(AWCemployee);
			clearAWCFormFields();
			refreshAWCTable();
			AWCemployee = null;
			
		}catch(Exception e){
			AWCempIDtextField.setText("Fields Must be Filled with the appropriate Data");
		}
		
		
	}
	
//the following two methods are use when the button "Delete Employee" is pressed from BMW or AWC
//the employee to be deleted must be search beforehand to become the current working instance to delete
	public void deleteBMWEmployee(){
		try{
			BMWremote.deleteEmployee(BMWemployee);
			BMWempIDtextField.setText("Type Employee ID Here");
			clearBMWFormFields();
			refreshBMWTable();
			BMWemployee = null;
		}catch(Exception e){
			BMWempIDtextField.setText("Employee must be searched using ID no. before Delete");
		}
		
	}
	
	public void deleteAWCemployee(){
		try{
			AWCremote.deleteEmployee(AWCemployee);
			AWCempIDtextField.setText("Type Employee ID Here");
			clearAWCFormFields();
			refreshAWCTable();
			AWCemployee = null;
		}catch(Exception e){
			AWCempIDtextField.setText("Employee must be searched using ID no. before Delete");
		}
	}
	
//the following two methods are use when the button "Update Employee Record" is pressed from BMW or AWC
//the employee to be updated must be search beforehand to become the current working instance to update
	public void updateBMWEmployeeRecord(){
		try{
			BMWemployee.setFullName(BMWfullNameTextField.getText());
	        BMWemployee.setJob(BMWjobTextField.getText());
	        BMWemployee.setMgr(Integer.parseInt(BMWmanagerIdTextField.getText()));
	        Date BMWdate = BMWdateFormat.parse(BMWhireDateTextField.getText());
	        java.sql.Date BMWsqlDate = new java.sql.Date(BMWdate.getTime());
			BMWemployee.setHireDate(BMWsqlDate);
	        BMWemployee.setSalary(Double.parseDouble(BMWsalaryTextField.getText()));
	        BMWemployee.setCommission(Double.parseDouble(BMWcommissionTextField.getText()));
	        BMWemployee.setDepartmentNo(Integer.parseInt(BMWdeptNoTextField.getText()));
	        BMWremote.updateEmployee(BMWemployee);
	        clearBMWFormFields();
	        refreshBMWTable();
	        BMWemployee = null;
		}catch(Exception e) {
		  	BMWempIDtextField.setText("Employee must be searched using ID no. before Update");
		}	
	}
	
	public void updateAWCEmployeeRecord(){
		try{
			AWCemployee.setNationalIDNo(AWCNationalIDTextField.getText());
			AWCemployee.setContactID(Integer.parseInt(AWCcontactIDTextField.getText()));
			AWCemployee.setLoginID(AWCloginIDTextField.getText());
			AWCemployee.setManagerID(Integer.parseInt(AWCmanagerIDTextField.getText()));
			AWCemployee.setTitle(AWCtitleTextField.getText());
			Date AWCdate = AWCdateFormat.parse(AWCbirthDateTextField.getText());
			java.sql.Date AWCsqlDate = new java.sql.Date(AWCdate.getTime());
			AWCemployee.setBirthDate(AWCsqlDate);
			
			String maritalValue = AWCmaritalStatuscomboBox.getSelectedItem().toString();
			if(maritalValue=="Married")
				AWCemployee.setMaritalStatus('M');
			else
				AWCemployee.setMaritalStatus('S');
			
			String genderValue = AWCgendercomboBox.getSelectedItem().toString();
			if(genderValue=="Male")
				AWCemployee.setGender('M');
			else
				AWCemployee.setGender('F');
			
			AWCdate = AWCdateFormat.parse(AWChireDateTextField.getText());
			AWCsqlDate = new java.sql.Date(AWCdate.getTime());
			AWCemployee.setHireDate(AWCsqlDate);
			
			String salariedValue = AWCsalariedcomboBox.getSelectedItem().toString();
			if(salariedValue=="YES")
				AWCemployee.setSalariedFlag('Y');
			else
				AWCemployee.setSalariedFlag('N');
			
			AWCemployee.setVacationHrs(Short.parseShort(AWCvacationHrsTextField.getText()));
			AWCemployee.setSickLeaveHrs(Short.parseShort(AWCsickleaveHrsTextField.getText()));
			
			String currentValue = AWCcurrentComboBox.getSelectedItem().toString();
			if(currentValue=="YES")
				AWCemployee.setCurrentFlag('Y');
			else
				AWCemployee.setSalariedFlag('N');
			
			Calendar cal = Calendar.getInstance();
			AWCdate = cal.getTime();
			AWCsqlDate = new java.sql.Date(AWCdate.getTime());
			AWCemployee.setModifiedDate(AWCsqlDate);
			
			AWCremote.updateEmployee(AWCemployee);
			clearAWCFormFields();
			refreshAWCTable();
			AWCemployee = null;
		}catch(Exception e){
			AWCempIDtextField.setText("Employee must be searched using ID no. before Update");
		}
	}

//methods to clear the fields of both forms
	public void clearBMWFormFields(){
		BMWretrievedEmpIdLabel.setText("****");
        BMWfullNameTextField.setText("");
        BMWjobTextField.setText("");
        BMWmanagerIdTextField.setText("");
        BMWhireDateTextField.setText("");
        BMWsalaryTextField.setText("");
        BMWcommissionTextField.setText("");
        BMWdeptNoTextField.setText("");
	}

	public void clearAWCFormFields(){
		AWCretrievedEmpIDLabel.setText("****");
		AWCNationalIDTextField.setText("");
		AWCcontactIDTextField.setText("");
		AWCloginIDTextField.setText("");
		AWCmanagerIDTextField.setText("");
		AWCtitleTextField.setText("");
		AWCbirthDateTextField.setText("");
		AWCmaritalStatuscomboBox.setSelectedIndex(0);
		AWCgendercomboBox.setSelectedIndex(0);
		AWChireDateTextField.setText("");
		AWCsalariedcomboBox.setSelectedIndex(0);
		AWCvacationHrsTextField.setText("");
		AWCsickleaveHrsTextField.setText("");
		AWCcurrentComboBox.setSelectedIndex(0);
		AWCmodifiedDateLabelResult.setText("****");
	}

//methods to refresh the tables
	public void refreshBMWTable(){
		bmwData = new DefaultTableModel(updateBMWTable(), BMWtableColumnNames);
        BMWemployeeTable.setModel(bmwData);
        BMWscrollPane.setViewportView(BMWemployeeTable);
	}
	public void refreshAWCTable(){
		awcData = new DefaultTableModel(updateAWCTable(), AWCtableColumnNames);
        AWCemployeeTable.setModel(awcData);
        AWCscrollPane.setViewportView(AWCemployeeTable);
	}

//methods to fill in the tables	
	public String[][] updateBMWTable(){
		BMWremote = doBMWLookup();
		bmwEmps = BMWremote.listAllEmployees();
		int rowCount = bmwEmps.size();
		int columnCount = 8;
		BMWEmployee emp;
		bmwEmpArray = new String [rowCount][columnCount];
		for(int i=0; i<rowCount; i++){
			emp = bmwEmps.get(i);
			bmwEmpArray[i][0] = Integer.toString(emp.getId());
			bmwEmpArray[i][1] = emp.getFullName();
			bmwEmpArray[i][2] = emp.getJob();
			bmwEmpArray[i][3] = Integer.toString(emp.getMgr());
			BMWstringDate = BMWdateFormat.format(emp.getHireDate());
			bmwEmpArray[i][4] = BMWstringDate;
			bmwEmpArray[i][5] = Double.toString(emp.getSalary());
			bmwEmpArray[i][6] = Double.toString(emp.getCommission());
			bmwEmpArray[i][7] = Integer.toString(emp.getDepartmentNo());
		}
		return bmwEmpArray;
		
	}
	
	public String[][] updateAWCTable(){
		AWCremote = doAWCLookup();
		awcEmps = AWCremote.listAllEmployees();
		int rowCount = awcEmps.size();
		int columnCount = 15;
		AWCEmployee AWCemp;
		awcEmpArray = new String [rowCount][columnCount];
		for(int i=0; i<rowCount; i++){
			AWCemp = awcEmps.get(i);
			awcEmpArray[i][0] = Integer.toString(AWCemp.getId());
			awcEmpArray[i][1] = AWCemp.getNationalIDNo();
			awcEmpArray[i][2] = Integer.toString(AWCemp.getContactID());
			awcEmpArray[i][3] = AWCemp.getLoginID();
			awcEmpArray[i][4] = Integer.toString(AWCemp.getManagerID());
			awcEmpArray[i][5] = AWCemp.getTitle();
			AWCstringDate = AWCdateFormat.format(AWCemp.getBirthDate());
			awcEmpArray[i][6] = AWCstringDate;
			
			if(AWCemp.getMaritalStatus()=='M')
				awcEmpArray[i][7] = "Married";
			else
				awcEmpArray[i][7] ="Single";
			
			if(AWCemp.getGender()=='M')
				awcEmpArray[i][8] = "Male";
			else
				awcEmpArray[i][8] = "Female";
			
			AWCstringDate = AWCdateFormat.format(AWCemp.getHireDate());
			awcEmpArray[i][9] = AWCstringDate;
			
			if(AWCemp.getSalariedFlag()=='Y')
				awcEmpArray[i][10] = "YES";
			else
				awcEmpArray[i][10] = "NO";
			
			awcEmpArray[i][11] = Short.toString(AWCemp.getVacationHrs());
			awcEmpArray[i][12] = Short.toString(AWCemp.getSickLeaveHrs());
			
			if(AWCemp.getCurrentFlag()=='Y')
				awcEmpArray[i][13] = "YES";
			else
				awcEmpArray[i][13] = "NO";
			AWCstringDate = AWCdateFormat.format(AWCemp.getModifiedDate());
			awcEmpArray[i][14] = AWCstringDate;
		}
		return awcEmpArray;
		
	}

//lookup methods to locate the remote Manage Bean to be used for each Company
	private static AWCEmployeeRemote doAWCLookup() {
        Context context1 = null;
        AWCEmployeeRemote awcBean = null;
        try {
            // 1. Obtaining Context
            context1 = getInitialContext();
            // 2. Lookup and cast
            awcBean = (AWCEmployeeRemote) context1.lookup(AWC_LOOKUP_STRING);
        } catch (NamingException e) {
            e.printStackTrace();
        }
        return awcBean;
    }
	
	private static BMWEmployeeRemote doBMWLookup() {
        Context context2 = null;
        BMWEmployeeRemote bmwBean = null;
        try {
            // 1. Obtaining Context
            context2 = getInitialContext();
            // 2. Lookup and cast
            bmwBean = (BMWEmployeeRemote) context2.lookup(BMW_LOOKUP_STRING);
        } catch (NamingException e) {
            e.printStackTrace();
        }
        return bmwBean;
    }
 
    private static final String BMW_LOOKUP_STRING = "java:global/SWM60-EnterpriseApplicationDevelopment/BMWManageEmployeeBean";
    private static final String AWC_LOOKUP_STRING = "java:global/SWM60-EnterpriseApplicationDevelopment/AWCManageEmployeeBean";
    
    /*
     *  * location of Glassfish JNDI Service provider the client will use. It should
     * be * URL string.
     */

    private static Context initialContext;
 
    public static Context getInitialContext() throws NamingException {
        if (initialContext == null) {
            // Properties extends HashTable
            
        	Properties props = new Properties();

        	  props.setProperty("java.naming.factory.initial",
        	                    "com.sun.enterprise.naming.SerialInitContextFactory");

        	  props.setProperty("java.naming.factory.url.pkgs",
        	                    "com.sun.enterprise.naming");

        	  props.setProperty("java.naming.factory.state",
        	                    "com.sun.corba.ee.impl.presentation.rmi.JNDIStateFactoryImpl");
        	
            initialContext = new InitialContext(props);
        }
        return initialContext;
    }

}
