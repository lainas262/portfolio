/*
 * Author: Emmanouil Lainas
 * Registration Number: 12847191
 * Module: Data Structures & Algorithms
 */

/*
 * For the Part two of the assignment a Double-Ended Queue needs to be
 * implemented. Two solutions are provided. A draft one Deque.java and a
 * final one DequeS.java(this file). Both solutions pass the predefined
 * tests, even the other extended tests. We will not discuss how Deque.java 
 * works since its more inefficient but generally the implementation uses
 * an ArrayList of null elements. The accessing, removing and inserting 
 * elements in the list costs much more than in the implementation done 
 * below which makes usage of head and tail pointers. The reason is because
 * access and update of an ArrayList costs more than accessing and updating
 * an array. Also another reason is because in Deque.java
 * the "head" is always set to index 0. This causes frequent, costly swapping. 
 * generally the Deque.java implementation is LESS efficient and MORE costly.
 * 
 * Running TestDeque.java 10 times 
 * gives the following time results:
 * 		
 * 		-0.006s
 * 		-0.006s
 * 		-0.004s
 * 		-0.005s
 * 		-0.010s
 * 		-0.004s
 * 		-0.006s
 * 		-0.008s
 * 		-0.007s
 * 		-0.010s
 * 
 * Running TestDequeS.java 10 times 
 * gives the following time results:
 * 		
 * 		-0.002s
 * 		-0.001s
 * 		-0.001s
 * 		-0.001s
 * 		-0.001s
 * 		-0.002s
 * 		-0.002s
 * 		-0.002s
 * 		-0.002s
 * 		-0.002s
 * 
 * From the results we can see how faster TestDequeS.java is.
 * 
 * Lets discuss how DequeS.java works. The properties of a Double-Ended 
 * Queue are that you can insert/remove elements at the head of the list, 
 * insert/remove elements at the tail of the list, pick the first element 
 * of the list, get the length of the list and check if the list is full.
 * Above each method there comments explaining its usage.
 * In TestDequeS tests are provided. testFullUnit is unit test completed
 * by me trying to check the deque for every possible case.
 */

package ci284.ass1;

import java.util.ArrayList;

public class DequeS {
	
	/*
	 * head variable initialised to 0 and tail to -1
	 * head and tail are our most important variables used
	 * because they will give us the range within our array
	 * that represents the queue. For example there might
	 * be cases where in a full array of 10 elements, because
	 * of constantly removing the front, we might end up with
	 * a deque of 10 elements occupied lets say at the 5 last 
	 * indexes of the array. Which means the position of head
	 * will be at deque[5] and the tail will point at deque[9]
	 * Using this pointers, we don't care how the array is 
	 * initialised and with what values, since the head and tail
	 * point us the range of our deque and are updated in every
	 * transaction. It is important to note that this 
	 * implementation intended to be as efficient as possible.
	 * Which means it tries to handle every possible case
	 * with as less operations as possible.
	 * More on that later
	 * max variable represents the size of the deque
	 * more efficient to use a variable holding the size
	 * of the deque than using the method array.length().
	 * deque is an array representing our deque
	 */
	int head=0;
	int tail=-1;
	int max;
	int[] deque;
	
	/*
	 * constructor of the deque
	 * initialises an aray of x integers
	 * so if x=5 then we would have
	 * [_,_,_,_,_] an array of five integer elements
	 * with the head pointing to position
	 * 0 and tail to -1
	 * The complexity of this code depends on the size
	 * of the array. And the most costly operations is 
	 * when inserting element at the front and the head 
	 * points to 0. And when inserting at the back and 
	 * the tail points to the last position of the deque
	 * max-1. In every other case the operations are
	 * done almost instantly.
	 */
	public DequeS(int x){
		max = x;
		deque = new int[max];
	}
	/*
	 * insert an element at the front of the deque.
	 * When inserting an element at the head there 
	 * are 4 cases that may arise.
	 * There is a case in which the deque is full.
	 * We will not deal with this case since we provide
	 * a method isFull() which means that the user
	 * (in this case the testing method) is responsible
	 * to check if the deque is full before inserting.
	 * The second case is when we have a deque of 5
	 * elements with only the 2 first occupied.
	 * [1,2,_,_,_] In this case we need to move
	 * the elements of the array one position(+1). Then
	 * insert the new element in front array(0). The head
	 * was pointing to 0 from before so nothing changes but
	 * we must update the tail position.[3,1,2,_,_]
	 * The 3rd case is when you have an array occupied at 
	 * the back [_,_,x,1,2]. In this case we need to move 
	 * the head one position back(x) and add the new element.
	 * The fourth case is when we have elements in the middle
	 * of the deque [x,1,2,_,_]. Again we move the head back(x).
	 * So to avoid more transactions we are only swapping 
	 * when our head is 0. In every other case we move the head
	 * one position back and add element.
	 */
	public void insertFront(int e){
		if(head==0){	
			for(int i=tail;i>=head;i--){
				deque[i+1]=deque[i];
			}
			deque[head]=e;
			tail++;
		}
		else{
			head--;
			deque[head]=e;
		}
	}
	
	/*
	 * insert an element at the back of the deque
	 * When inserting an element at the back of the deque
	 * the same case as when inserting to the front may 
	 * arise and we will deal with it in the same way.
	 * If the list is occupied at the end, which means the
	 * tail to be pointing at the last position of the deque
	 * then we will swap the elements one position to the left
	 * and we will decrease the head by 1. Otherwise we will
	 * increase the tail by 1 and add the new element to that 
	 * position. This means that the more cost will be only 
	 * when our tail point at the end of the deque.
	 */
	public void insertBack(int e){
		if(tail==max-1){
			for(int i=head;i<=max-1;i++){
				deque[i-1]=deque[i];
			}
			deque[tail]=e;
			head--;
		}
		else{
			tail++;
			deque[tail]=e;
		}
	}
	
	/*
	 * remove the element at the front of the deque
	 * When removing the Front, the cost of the operation
	 * is minimal because what actually happens is that
	 * the position of the head moves one position to the
	 * right. But in order for our deque to work there are
	 * some checks that we must do. If our deque is empty
	 * which means for the head to overpass the tail we
	 * must throw a runtime exception. Otherwise we need
	 * to check if the head is already pointing to the last
	 * position of the deque. If so we "remove the front"
	 * by reseting the values of head and tail to the initial
	 * values. 0 and -1 respectively. In every other case we 
	 * just change the position of the pointer by increasing
	 * it by 1. We also need to return the number removed.
	 */
	public int removeFront() throws RuntimeException{
		int x=0;
		if(tail<head){
			throw new RuntimeException();
		}
		else if(head==max-1){
			x=deque[head];
			head=0;
			tail=-1;
		}
		else {
			x=deque[head];
			head++;	
		}
		return x;
	}
	
	/*
	 * remove the element at the back of the deque
	 * Removing an element from the back of the deque
	 * is similar as when removing an element from
	 * the front. The same idea will be used by just
	 * decreasing the value of the tail by 1.
	 * There is one case that we need to check for. 
	 * We need to check if the deque
	 * is empty and throw a runtime exception. 
	 * This is done the same way as above, by
	 * checking if the head overpasses the tail.
	 * If its not empty decrease the tail by 1.
	 */
	
	public int removeBack() throws RuntimeException{
		int x=0;
		if(tail<head){
			throw new RuntimeException();
		}
		else{
			x=deque[tail];
			tail--;
		}
		return x;
	}
	
	/*
	 * return the element at the front of the deque
	 * without removing it
	 * What we need to do for the peek method is to
	 * check if the deque is not empty return the front.
	 * This is done by checking again if the head 
	 * overpasses the tail then throw a runtime exception
	 * otherwise return the element from the position that
	 * the head points.
	 */
	
	public int peek() throws RuntimeException{
		int picked;
		if(tail<head){
			throw new RuntimeException();
		}
		else{
			picked = deque[head];
			return picked;
		}
	}
	
	/*
	 * returns the number of elements in the deque
	 * For this method we need to subtract the head
	 * from the tail and then add 1. For example
	 * [_,_,2,4,_]. In this case
	 * head=2
	 * tail=3
	 * (3-2)+1=2 elements.
	 * Low cost operations.
	 */
	public int length(){
		int len=0;
		len = tail-head+1;
		return len;
	}
	
	/* returns true if the deque is full,
	 * false otherwise
	 * Our deque is full only when the head
	 * points to the first position (0) AND 
	 * the tail to the last position (max-1)
	 * tail-head==max-1 what is actually done
	 * here is that the statement 
	 * 	if (tail==0 && head==max-1)
	 * 		true
	 * is translated to a single comparison using
	 * mathematical operation which cost less.
	 */
	public boolean isFull(){
		if(tail-head==max-1){
			return true;
		}
		else{
			return false;
		}
	}
}
