/*
 * Author: Emmanouil Lainas
 * Registration Number: 12847191
 * Module: Data Structures & Algorithms
 */

// First attempt Draft

package ci284.ass1;
import java.util.ArrayList;
public class Deque {
	
	ArrayList<Integer> deque = new ArrayList<Integer>();
	  
	public Deque(int x){
		int max = x;
		for(int i=0;i<max;i++){
		deque.add(null);
		}		
	}
	
	//insert an element at the front of the deque
	/* Because there is no use of head here the algorithms
	 * used are much more complex. Loops are used just to
	 * keep the count of occupied indexes so that we know 
	 * untill when to swap. We will not explain this code
	 * in detail but the idea is that our first element is 
	 * always at position 0 of the ArrayList. In order to 
	 * keep the head stable lots of swappings must be 
	 * performed when inserting at front and when removing 
	 * at front. Also costly loops are being used when 
	 * inserting or removing at back untill we find a null 
	 * position to add or remove an element.
	 */
	public void insertFront(int e){ 
		int count=0;
		int insertfront =e;
		if(deque.get(0)==null){
			deque.set(0, insertfront);
		}
		else{
			for(int i=0; i<deque.size();i++){
				if(deque.get(i)!=null){
					count++;
				}
			}
				for(int i=count; i>0;i--){
					deque.set(i,deque.get(i-1));
				}
				deque.set(0, insertfront);
		}   
		
	}
	
	//insert an element at the back of the deque
	public void insertBack(int e){
		int insertback = e;
		if(deque.get(0)==null){
			deque.set(0,insertback);
		}
		else {
			int i=0;
			while(deque.get(i)!=null){
				i++;
			}
			deque.set(i,insertback);
		}
	}
	
	
	//remove the element at the front of the deque
	public int removeFront() throws RuntimeException{
		int temp;
		int x=0;
		int count =0;
		if(deque.get(0)==null){
			throw new RuntimeException();
		}
		else{
			for(int i=0; i<deque.size();i++){
				if(deque.get(i)!=null){
					count++;
				}
			}
			if(count==deque.size()){
				x=deque.get(0);
				deque.set(0, null);
				for(int i=0;i<deque.size()-1;i++){
					temp = deque.get(i);
					deque.set(i,deque.get(i+1));
					deque.set(i+1, temp);
				}
			}
			else{
				x=deque.get(0);
				deque.set(0,null);
				for(int i=0;i<count-1;i++){
					temp = deque.get(i);
					deque.set(i,deque.get(i+1));
					deque.set(i+1, temp);
				}
			}
		return x;
		}
	}
	
	//remove the element at the back of the deque
	public int removeBack() throws RuntimeException{
		int count=0;
		int x=0;
		if(deque.get(0)==null){
			throw new RuntimeException();
		}
		else{
			for(int i=0; i<deque.size();i++){
				if(deque.get(i)!=null){
					count++;
				}
			}
			if(count+1==deque.size()){
				x=deque.get(count);
				deque.set(count, null);
				
			}else{
				x=deque.get(count-1);
				deque.set(count-1,null);
				
			}
			return x;
		}
	}
	
	//return the element at the front of the deque
	//without removing it
	public int peek() throws RuntimeException{
		int picked;
		if(deque.get(0)==null){
			throw new RuntimeException();
		}
		else{
			picked = deque.get(0);
			return picked;
		}
	}
	
	//returns the number of elements in the deque
	public int length(){
		int len=0;
		for(int i=0; i<deque.size(); i++){
			if(deque.get(i)!=null){
				len=len+1;
			}
		}
		return len;
	}
	
	//returns true if the deque is full,
	//false otherwise
	public boolean isFull(){
		int count=0;
		boolean flag;
		if(deque.get(0)==null){
			flag=false;
			return flag;
		}
		else{
			for(int i=0; i<deque.size(); i++){
				if(deque.get(i)!=null){
					count++;
				}
			}
			if(count==deque.size()){
				flag=true;
			}
			else{
				flag=false;
			}
			return flag;
		}	
	}

}
