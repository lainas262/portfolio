package ci284.ass1.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Random;

import org.junit.Test;

import ci284.ass1.DequeS;

public class TestDequeS {
	@Test
	public void testFrontAndLength() {
		DequeS d = new DequeS(1);
		d.insertFront(1);
		assertEquals(1, d.length());
		int f = d.removeBack();
		assertEquals(1, f);
		
		int max = (new Random()).nextInt(99);
		d = new DequeS(max);
		for(int i=0;i<max;i++) {
			d.insertFront(i);
		}
		assertEquals(max, d.length());
	}
	
	@Test
	public void testRemoveFrontThrows() {
		DequeS d = new DequeS(1);
		d.insertFront(1);
		d.removeFront();
		try {
			d.removeFront();
			fail("Removed from front of an empty Deque but didn't fail");
		} catch (RuntimeException e){
			assertTrue(true);
		}
	}
	
	@Test
	public void testRemoveBackThrows() {
		DequeS d = new DequeS(1);
		d.insertFront(1);
		d.removeBack();
		try {
			d.removeBack();
			fail("Removed from front of an empty Deque but didn't fail");
		} catch (RuntimeException e){
			assertTrue(true);
		}
	}
	
	@Test
	public void testBackAndLength() {
		DequeS d = new DequeS(1);
		d.insertBack(1);
		assertEquals(1, d.length());
		int b = d.removeBack();
		assertEquals(1, b);
		
		int max = (new Random()).nextInt(99);
		d = new DequeS(max);
		for(int i=0;i<max;i++) {
			d.insertBack(i);
		}
		assertEquals(max, d.length());
	}
	
	@Test
	public void testIsFull() {
		DequeS d = new DequeS(1);
		d.insertFront(1);
		assertTrue(d.isFull());
		
		d.removeFront();
		assertFalse(d.isFull());
		
		d = new DequeS(10);
		for(int i=0;i<10;i++) {
			d.insertFront(i);
		}
		assertTrue(d.isFull());
	}
	
	@Test
	public void testPeek() {
		DequeS d = new DequeS(10);
		d.insertFront(1);
		assertEquals(1, d.peek());
		assertEquals(1, d.length());
		d.removeFront();
		try {
			d.peek();
			fail("Peeked into an empty Deque but didn't fail");
		} catch (RuntimeException e){
			assertTrue(true);
		}
	}
	
	@Test
	public void testInsertThenRemoveJIM() {
		DequeS d = new DequeS(5);
		d.insertFront(1);
		d.insertBack(1);
		d.insertFront(1);
		d.insertBack(1);
		d.insertFront(1);

		d.removeBack();
		d.removeFront();
		d.removeBack();
		d.removeFront();
		d.removeBack();

		assertTrue(d.length()==0);
	}
	
	//My test, monitoring the values of the deque in comments
	@Test
	public void testFullUnit(){
		DequeS d = new DequeS(5);
		//[_,_,_,_,_]
		
		assertFalse(d.isFull());
		assertEquals(d.length(),0);
		
		d.insertFront(4);
		//[4,_,_,_,_]
		assertEquals(d.peek(),4);
		assertFalse(d.isFull());
		assertEquals(d.length(),1);
		
		d.insertBack(6);
		//[4,6,_,_,_]
		assertEquals(d.peek(),4);
		assertFalse(d.isFull());
		assertEquals(d.length(),2);
		
		d.insertFront(5);
		//[5,4,6,_,_]
		assertEquals(d.peek(),5);
		assertFalse(d.isFull());
		assertEquals(d.length(),3);
		
		d.insertBack(84);
		//[5,4,6,84,_]
		assertEquals(d.peek(),5);
		assertFalse(d.isFull());
		assertEquals(d.length(),4);
		
		d.insertFront(2);
		//[2,5,4,6,84]
		assertEquals(d.peek(),2);
		assertTrue(d.isFull());
		assertEquals(d.length(),5);
		
		d.removeFront();
		//[_,5,4,6,84]
		assertEquals(d.peek(),5);
		assertFalse(d.isFull());
		assertEquals(d.length(),4);
		
		d.removeFront();
		//[_,_,4,6,84]
		assertEquals(d.peek(),4);
		assertFalse(d.isFull());
		assertEquals(d.length(),3);
		
		d.removeBack();
		//[_,_,4,6,_]
		assertEquals(d.peek(),4);
		assertFalse(d.isFull());
		assertEquals(d.length(),2);
		
		d.removeFront();
		//[_,_,_,6,_]
		assertEquals(d.peek(),6);
		assertFalse(d.isFull());
		assertEquals(d.length(),1);
		
		d.insertBack(43);
		//[_,_,_,6,43]
		assertEquals(d.peek(),6);
		assertFalse(d.isFull());
		assertEquals(d.length(),2);
		
		d.insertBack(7);
		//[_,_,6,43,7]
		assertEquals(d.peek(),6);
		assertFalse(d.isFull());
		assertEquals(d.length(),3);
		
		d.insertBack(15);
		//[_,6,43,7,15]
		assertEquals(d.peek(),6);
		assertFalse(d.isFull());
		assertEquals(d.length(),4);
		
		d.insertFront(3);
		//[3,6,43,7,15]
		assertEquals(d.peek(),3);
		assertTrue(d.isFull());
		assertEquals(d.length(),5);
		
		d.removeFront();
		//[_,6,43,7,15]
		assertEquals(d.peek(),6);
		assertFalse(d.isFull());
		assertEquals(d.length(),4);
		
		d.removeFront();
		//[_,_,43,7,15]
		assertEquals(d.peek(),43);
		assertFalse(d.isFull());
		assertEquals(d.length(),3);
		
		d.removeFront();
		//[_,_,_,7,15]
		assertEquals(d.peek(),7);
		assertFalse(d.isFull());
		assertEquals(d.length(),2);
		
		d.removeFront();
		//[_,_,_,_,15]
		assertEquals(d.peek(),15);
		assertFalse(d.isFull());
		assertEquals(d.length(),1);
		
		d.removeFront();
		//[_,_,_,_,_]
		
		try {
			d.peek();
			fail("Peeked into an empty Deque but didn't fail");
		} catch (RuntimeException e){
			assertTrue(true);
		}
		assertFalse(d.isFull());
		assertEquals(d.length(),0);
		
/*
 * if the NEXT statement is changed to insertBack(5)
 * it will pass the test as well.
 * this means that when we need to go from state
 * [_,_,_,_,15] to [_,_,_,_,_] the head and tail are reset
 */
		d.insertFront(5);
		//[5,_,_,_,_]
		assertEquals(d.peek(),5);
		assertFalse(d.isFull());
		assertEquals(d.length(),1);
		
		d.removeBack();
		//[_,_,_,_,_]
		try {
			d.removeBack();
			fail("Removed from front of an empty Deque but didn't fail");
		} catch (RuntimeException e){
			assertTrue(true);
		}
		try {
			d.removeFront();
			fail("Removed from front of an empty Deque but didn't fail");
		} catch (RuntimeException e){
			assertTrue(true);
		}
	}
}
