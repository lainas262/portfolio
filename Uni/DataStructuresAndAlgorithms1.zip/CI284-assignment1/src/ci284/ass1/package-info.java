/**
 * Implement your solutions to assignment one in this package, in two classes called
 * OddEvenSort and Deque.
 */
/**
 * @author jb259
 *
 */
package ci284.ass1;