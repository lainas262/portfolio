/*
 * Author: Emmanouil Lainas
 * Registration Number: 12847191
 * Module: Data Structures & Algorithms
 */

/*
 * When using Bubble Sort, the best case is when the list
 * to be sorted is already sorted. The algorithm runs n-1 comparisons
 * on a list with n elements, and no swaps are needed. In the worst case,
 * meaning that the list is in reverse order, the algorithm will run
 * n-1 comparisons in the first pass, n-2 comparisons in the second pass
 * and so on including swaps, until the list is sorted. The complexity
 * of Bubble Sort is O(n^2) because we carry O(n) tasks n times. When 
 * running Odd-Even sort on a single processor unit or sequentially, there 
 * is not really a difference with Bubble Sort. Again, in the best case 
 * the algorithm is already sorted and n-1 comparisons will take place,
 * and in the worst case (reverse order)  the complexity is again 0(n^2)
 * The interesting thing is when running the algorithm on multiple
 * processors or in parallel. With shared memory, if the odd indexes are
 * checked in one processor and the even indexes are checked in another,
 * then the complexity of the algorithm (O) would be FLOOR of (n^2)/2.
 * This means that on multiple processors this algorithm would run twice 
 * as fast than Bubble Sort. What we could say is that Odd-Even Sort is 
 * basically Bubble Sort but for multiple processors.
 */

package ci284.ass1;

public class OddEvenSort {
	
	public int[] sort(int[] array){
		
		// create array
		int[] x=array;
		
		// we alwawys need at least one pass
		//to check if the list is sorted so we
		//set it to FALSE
		boolean sorted=false;
		
		
		while(!sorted){
			sorted = true;
			int i=1;
		//sort odd indexes by comparing and swaping
			while(i<x.length-1){
				if(x[i]>x[i+1]){
					int temp = x[i];
					x[i]=x[i+1];
					x[i+1]=temp;
					sorted=false;
				}
				i=i+2;
			}
			i=0;
		//sort even indexes by comparing and swaping	
			while(i<x.length-1){
				if(x[i]>x[i+1]){
					int temp = x[i];
					x[i]=x[i+1];
					x[i+1]=temp;
					sorted=false;
				}
				i=i+2;
			}
		}
		return x;
	}


}
